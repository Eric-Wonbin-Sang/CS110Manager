import os
import csv
import matplotlib.pyplot as plt

class Day:

    def __init__(self, stock_name, row):
        self.stock_ticker= stock_name
        self.date = row[0]
        self.opening = float(row[2].replace(',', ''))
        self.high = float(row[3].replace(',', ''))
        self.low = float(row[4].replace(',', ''))
        self.closing = float(row[1].replace(',', ''))
        self.daily_average = self.get_daily_average()
        self.daily_change = float(row[6].replace('%', ''))

    def get_daily_average(self):
        return (self.opening +self.closing)/2

    def __str__(self):
        return "Day obj - date: {}, closing: {}, da {}, dc {}".format(self.date, self.closing, self.daily_average, self.daily_change)

class Sector():
    def __init__(self, file):
        self.file = file
        self.filename = self.getfilename()
        self.daylist = self.getdaylist()

    def getfilename(self):
        return self.file.split(" ")[-1][:-4]

    def getdaylist(self):
        daylist = []
        with open(self.file) as stockfile:
            rowlist = csv.reader(stockfile)
            for rowindex, row in enumerate(rowlist):
                if rowindex != 0:
                    daylist.append(Day(self.filename, row))
        return daylist

    def graph(self):
        datelist = [day.date for day in self.daylist]
        dailychangelist = [day.daily_change for day in self.daylist]
        plt.plot(datelist, dailychangelist, label=self.filename)


def main():
    validchoice = 0
    first_file_choice = eval(input('Enter: \n 1 for Health Care \n 2 for Technology \n 3 for Financials \n 4 for Industrials \n'))
    if first_file_choice ==1:
        first_file_path = 'C:\\Users\\cgera\\OneDrive\\Desktop\\Stevens Classes 2020\\CS 110-A\\2020.01.01 - 2020.05.01 DJHealthcare.csv'
        first_sector = Sector(first_file_path)
        first_sector.graph()
    elif first_file_choice ==2:
        first_file_path = 'C:\\Users\\cgera\\OneDrive\\Desktop\\Stevens Classes 2020\\CS 110-A\\2020.01.01 - 2020.05.01 DJTech.csv'
        first_sector = Sector(first_file_path)
        first_sector.graph()
    elif first_file_choice == 3:
        first_file_path = 'C:\\Users\\cgera\\OneDrive\\Desktop\\Stevens Classes 2020\\CS 110-A\\2020.01.01 - 2020.05.01 DJFinancials.csv'
        first_sector = Sector(first_file_path)
        first_sector.graph()
    elif first_file_choice == 4:
        first_file_path = 'C:\\Users\\cgera\\OneDrive\\Desktop\\Stevens Classes 2020\\CS 110-A\\2020.01.01 - 2020.05.01 DJIndustrials.csv'
        first_sector = Sector(first_file_path)
        first_sector.graph()
    else:
        print("Invalid Choice")
        validchoice = 1

    if validchoice == 0:
        second_file_choice = eval(input('Enter: \n 1 for Health Care \n 2 for Technology \n 3 for Financials \n 4 for Industrials \n'))
        if second_file_choice == 1:
            second_file_path = 'C:\\Users\\cgera\\OneDrive\\Desktop\\Stevens Classes 2020\\CS 110-A\\2020.01.01 - 2020.05.01 DJHealthcare.csv'
            second_sector = Sector(second_file_path)
            second_sector.graph()
        elif second_file_choice == 2:
            second_file_path = 'C:\\Users\\cgera\\OneDrive\\Desktop\\Stevens Classes 2020\\CS 110-A\\2020.01.01 - 2020.05.01 DJTech.csv'
            second_sector = Sector(second_file_path)
            second_sector.graph()
        elif second_file_choice == 3:
            second_file_path = 'C:\\Users\\cgera\\OneDrive\\Desktop\\Stevens Classes 2020\\CS 110-A\\2020.01.01 - 2020.05.01 DJFinancials.csv'
            second_sector = Sector(second_file_path)
            second_sector.graph()
        elif second_file_choice == 4:
            second_file_path = 'C:\\Users\\cgera\\OneDrive\\Desktop\\Stevens Classes 2020\\CS 110-A\\2020.01.01 - 2020.05.01 DJIndustrials.csv'
            second_sector = Sector(second_file_path)
            second_sector.graph()
        else:
            print("Invalid Choice")
            validchoice = 1
    if validchoice == 0:
        plt.xlabel('Date')
        plt.ylabel('Daily Change')
        plt.title('Sectors Comparison Graph')
        plt.xticks(rotation=90)
        plt.legend()
        plt.grid()
        plt.show()



main()