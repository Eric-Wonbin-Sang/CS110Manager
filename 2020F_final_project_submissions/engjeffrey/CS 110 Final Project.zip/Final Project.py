import os
import csv
import sys
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
    
class Steam:
    def __init__(self, csv_row):
        self.date = csv_row[0]
        self.num_users = int(csv_row[1])

class Among_Us:
    def __init__(self, csv_row):
        self.date = csv_row[0]
        self.players = int(csv_row[1])
        self.twitch_viewers = int(csv_row[2])

def set_subplot(splot, x, y, ylbl):
    locator = mdates.MonthLocator()
    fmt = mdates.DateFormatter("%b")
    splot.grid()
    splot.xaxis.set_major_locator(locator)
    splot.xaxis.set_major_formatter(fmt)
    splot.plot(x, y)
    splot.set(ylabel = ylbl)

#Checks if file exists in working directory
def check_file(x):
    if os.path.isfile(x):
        print("Valid file.")
    else:
        print("The file does not exist.")
        sys.exit()

def main():
    csv_file_path = os.getcwd()
    steam_file = str(input("What is the Steam file name? "))
    steam_filename = csv_file_path + "/" + steam_file
    check_file(steam_filename)

    among_us_file = str(input("What is the Among Us file name? "))
    among_us_filename = csv_file_path + "/" + among_us_file
    check_file(among_us_filename)

    #Prompts for year and checks if it is valid
    year = str(input("What year do you want to analyze, 2019 or 2020? "))
    if year != "2019" and year != "2020":
        print("You did not enter one of the listed years.")
        sys.exit()
    
    with open(steam_filename, "r") as steam_csv:
        steam_reader = csv.reader(steam_csv, delimiter=",")
        steam_list = []
        for row_index, row in enumerate(steam_reader):
            #Excludes first row because it is headers
            if row_index != 0:
                #Splits each date of each row into month, day, and year
                a = row[0].split("/")
                #Checks if row's year is equal to inputted year
                if a[2] == year:
                    steam_list.append(Steam(row))

    steam_date_list = []
    steam_users_list = []
    for i in steam_list:
        steam_date_list.append(i.date)
        steam_users_list.append(i.num_users)

    with open(among_us_filename, "r") as among_us_csv:
        among_us_reader = csv.reader(among_us_csv, delimiter = ",")
        among_us_list = []
        for row_index, row in enumerate(among_us_reader):
            #Excludes first row because it is headers
            if row_index != 0:
                #Splits each date of eaach row into month, day, and year
                a = row[0].split("/")
                #Checks if row's year is equal to inputted year
                if a[2] == year:
                    among_us_list.append(Among_Us(row))

    among_us_date_list = []
    among_us_players_list = []
    among_us_twitch_viewers_list = []
    for i in among_us_list:
        among_us_date_list.append(i.date)
        among_us_players_list.append(i.players)
        among_us_twitch_viewers_list.append(i.twitch_viewers)

    #Adjusts figure to fit window
    fig, (ax1, ax2, ax3) = plt.subplots(3)
    fig.set_figheight(4)
    fig.set_figwidth(5)
    fig.tight_layout()
    fig.suptitle("Comparison of Steam Users, Among Us Players and Among Us Twitch Viewers in " + year)

    #Creates 3 subplots for the 3 trends
    set_subplot(ax1, steam_date_list, steam_users_list, "Steam Users")
    set_subplot(ax2, among_us_date_list, among_us_players_list, "Among Us Players")
    set_subplot(ax3, among_us_date_list, among_us_twitch_viewers_list, "Among Us Twitch Viewers")

    plt.show()
    print("The graphs have successfully been created.")
main()
