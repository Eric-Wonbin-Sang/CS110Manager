# I pledge my honor that I have abided by the Stevens Honor System
# Gabrielle Armetta

# This Python program will have the user select one stock from three options of stocks
# And the program will display data on a date the  user will enter of the stock in the year 2019

import pandas as pd


class Stocks:

    def print_data(stock):
        date = input("Enter a date in the form (mm-dd):")
        real_date = "2019-"+date
        data = pd.read_csv(stock)
        print(data.loc[data["Date"]==real_date])


def main():
    stocklist = ["AAPL.csv", "TSLA.csv", "FB.csv"]
    while 1:
        print("Press 1 for the stock of Apple.")
        print("Press 2 for the stock of Tesla.")
        print("Press 3 for the stock of Facebook.")
        choice = input()

        if choice == "1":
            Stocks.print_data(stocklist[0])
        elif choice == "2":
            Stocks.print_data(stocklist[1])
        elif choice == "3":
            Stocks.print_data(stocklist[2])
        else:
            break


main()