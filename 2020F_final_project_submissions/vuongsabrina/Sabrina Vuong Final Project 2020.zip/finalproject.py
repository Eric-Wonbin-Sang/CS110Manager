import csv
import matplotlib.pyplot as plt
import os

os.chdir("C:\\Users\loltu\Documents\Stevens Institute of Technology\CS 110\Data")

class Country():
    def __init__(self, name, dates, percents_of_baseline, avg_pob):
        self.name = name
        self.dates = dates
        self.percents_of_baseline = percents_of_baseline
        self.avgDates = dates[13:]
        self.avgPOB = avg_pob

def temp_pob_avg(temp_pob):
    sum = 0
    for i in range(len(temp_pob)):
        sum+=float(temp_pob[i])
    return sum/len(temp_pob)

def main():
    print("Program loading...please wait.")
    label_countries_list = ["Australia",
                            "Canada",
                            "Chile",
                            "United States of America (the)"]
    csv_file_path = "covid_impact_on_airport_traffic.csv"
    data = open(csv_file_path)
    row_list = csv.reader(data)
    row_enumeration = list(enumerate(row_list))

    country_list = []
    date_append = []
    pob_append = []
    isCountry = True
    for country in range(len(label_countries_list)):  # First look at Country
        dates = []  # new country, new dates
        percents_of_baseline = []  # new country, new baselines
        avg_pob = []
        for row_index, row in row_enumeration:  # look at all the rows (country considered)
            if ((row_index != 0) & (row[9] == label_countries_list[country])):
                date = row[1]
                temp_pob = []  # clear temp pobs
                for row_index, row in row_enumeration:  # look at all the rows (date considered)
                    if row_index != 0:
                        if ((row[1] == date) & (row[9] == label_countries_list[country])):
                            temp_pob.append(row[4])
                # then average the temp pobs
                if(len(dates)==0):
                    percents_of_baseline.append(temp_pob_avg(temp_pob))
                    dates.append(date)
                elif(date!=dates[len(dates)-1]):
                    percents_of_baseline.append(temp_pob_avg(temp_pob))
                    dates.append(date)
        for i in range(len(percents_of_baseline)):
            avgSum = 0
            if(i>=13):
                for j in range(13):
                    avgSum+=percents_of_baseline[i-j]
                avg_pob.append(avgSum/13.0)
        country_list.append(Country(label_countries_list[country], dates, percents_of_baseline, avg_pob))

    print("This program compares traffic to and from airports, as a percentage of a previously measured baseline from 2/15/2020 to 3/15/2020.")
    print("Please enter the name of the country that you'd like to compare to the U.S. (Australia, Canada, Chile)")
    invalid = True
    choice = 3
    while(invalid):
        chosen_country = str(input(""))
        chosen_country = chosen_country.lower()
        if(chosen_country=="australia"):
            invalid=False
            choice = 0
        elif(chosen_country=="canada"):
            invalid=False
            choice = 1
        elif(chosen_country=="chile"):
            invalid=False
            choice = 2
        else:
            print("That data is not available. Please choose between Australia, Canada, and Chile.")

    invalid2 = True
    choice2 = 2
    print("Would you like to compare raw data or the 14-day moving average? Enter 0 for raw data, 1, for 14-day moving average.")
    while (invalid2):
        chosen_graph = str(input(""))
        if (chosen_graph== "0"):
            invalid2 = False
            choice2 = 0
        elif (chosen_graph == "1"):
            invalid2 = False
            choice2 = 1
        else:
            print("Please select a valid value. Enter 0 for raw data, 1, for 14-day moving average.")

    if(choice2==0):
        plt.plot(country_list[3].dates, country_list[3].percents_of_baseline, label=country_list[3].name)
        plt.plot(country_list[choice].dates, country_list[choice].percents_of_baseline, label=country_list[choice].name)
        plt.title("Percent of Airport Travel Traffic as Compared to Baseline")
    else:
        plt.plot(country_list[3].avgDates, country_list[3].avgPOB, label=country_list[3].name + " avg")
        plt.plot(country_list[choice].avgDates, country_list[choice].avgPOB, label=country_list[choice].name + " avg")
        plt.title("14-day Moving Average of Percent of Airport Travel Traffic as Compared to Baseline")

    plt.ylabel("Percent of Baseline")
    plt.xlabel("Date")
    plt.xticks(rotation=90)
    plt.legend(loc='upper left')
    print("Graph has loaded. Please view it in the new window.")
    plt.show()
main()