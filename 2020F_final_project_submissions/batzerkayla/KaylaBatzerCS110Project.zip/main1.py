# Kayla Batzer Personal Project
# I pledge my honor to abide by the Stevens Honor Code


import csv
from matplotlib import pyplot as plt
import matplotlib.dates
import numpy as np
from sklearn.linear_model import LinearRegression
import datetime


def bestFit(x,y):
    newx = np.array([date.timestamp() for date in x]).reshape(-1,1)
    newy = np.array(y)
    model = LinearRegression()
    model.fit(newx, newy)
    yPredicted = model.predict(newx)
    slope = model.coef_
    if slope > 0:
        print("The slope of the line of best fit is positive.")
        print("The share price is trending upward.")
    elif slope < 0:
        print("The slope of the line of best fit is negative.")
        print("The share price is trending downward.")
    elif slope == 0:
        print("The slope of the line of best fit is 0.")
        print("The share price is not trending upward or downward.")
    else:
        print("The slope cannot be calculated and no conclusion can be made.")
    plt.plot(x, yPredicted, color='r')

def getStockInfo(csvPath, stockName):
    x = []
    y = []
    csvFile = open(csvPath, 'r')
    plots = csv.reader(csvFile)
    next(plots)
    for row in plots:
        x.append(datetime.datetime.strptime(row[0], "%Y-%m-%d"))
        y.append(float(row[4]))
    x = x[-30:]
    y = y[-30:]
    plt.yticks(np.arange(min(y)-10, max(y)+10, 1))
    plt.gca().xaxis.set_major_formatter(matplotlib.dates.DateFormatter('%m/%d/%Y'))
    plt.gca().xaxis.set_major_locator(matplotlib.dates.DayLocator(interval=10))
    plt.xlabel("Date")
    plt.ylabel("Close")
    plt.title("{} Share Price".format(stockName))
    plt.plot(x, y)
    bestFit(x, y)
    plt.grid()
    print("The minimum share price within the period is:", min(y))
    print("The maximum share price within the period is:", max(y))
    plt.show()

def main():

    stockCsvPathList = [
       "Source Files/AAPL.csv", "Source Files/AMGN.csv",
        "Source Files/AXP.csv", "Source Files/BA.csv",
        "Source Files/CAT.csv", "Source Files/CRM.csv",
        "Source Files/CSCO.csv", "Source Files/CVX.csv",
        "Source Files/DIS.csv", "Source Files/DOW.csv",
        "Source Files/GS.csv", "Source Files/HD.csv",
        "Source Files/HON.csv", "Source Files/IBM.csv",
        "Source Files/INTC.csv", "Source Files/JNJ.csv",
        "Source Files/JPM.csv", "Source Files/KO.csv",
        "Source Files/MCD.csv", "Source Files/MMM.csv",
        "Source Files/MRK.csv", "Source Files/MSFT.csv",
        "Source Files/NKE.csv", "Source Files/PG.csv",
        "Source Files/TRV.csv", "Source Files/UNH.csv",
        "Source Files/V.csv", "Source Files/VZ.csv",
        "Source Files/WBA.csv", "Source Files/WMT.csv"
    ]

    print("This is a python program that will analyze " 
          "stocks in the Dow Jones Industrial Index.")
    print("It will graph the share price of a stock from the DJI "
          "over the past 30 days the market has been open.")
    print("The program will then create a line of best fit and determine " 
          "if the share price has been trending op or down.")
    print("It will also determine the minimum and maximum share price during "
          "that time.")
    company = input("Enter the ticker (in lower case) of a company belonging to the Dow Jones Industrial Index: ")

    didSomething = False
    for stockCsvPath in stockCsvPathList:
        ticker = stockCsvPath.split("/")[-1][:-4].lower()
        if ticker == company.lower():
            getStockInfo(stockCsvPath, company.upper())
            didSomething = True
            break

    if not didSomething:
        print("The ticker you have entered is not in the index.")
        print("Please try again.")

main()



