import csv
import matplotlib.pyplot as plt


def graph_x_list_and_y_list(x_list, y_list, ticker):
    plt.plot(x_list, y_list, label=ticker)

def update_and_show_graph():
    plt.xlabel('Date')
    plt.ylabel('Percent Change')
    plt.xticks(rotation=90)
    plt.title('TSLA Percent Change vs HAIL Percent Change')
    plt.legend()
    plt.grid()
    plt.show()

def main():

    #Instantiate TSLA.csv
    T_csv_file_path = '/Users/matthewmascolo/Desktop/CS 110/Final Project/TSLA.csv'
    #Instantiate HAIL.csv
    H_csv_file_path = '/Users/matthewmascolo/Desktop/CS 110/Final Project/HAIL.csv'
    

    #TSLA Data
    T_date_list = []
    T_opening_list = []
    T_closing_list = []

    #HAIL Data
    H_date_list = []
    H_opening_list = []
    H_closing_list = []

    #TSLA Data Loop
    with open(T_csv_file_path) as T_csv_file:
        T_row_list = csv.reader(T_csv_file)
        for T_row_index, T_row in enumerate(T_row_list):
            if T_row_index != 0:
                T_date_list.append(T_row[0])
                T_opening_list.append(float(T_row[1]))
                T_closing_list.append(float(T_row[4]))

    #HAIL Data Loop
    with open(H_csv_file_path) as H_csv_file:
        H_row_list = csv.reader(H_csv_file)
        for H_row_index, H_row in enumerate(H_row_list):
            if H_row_index !=0:
                H_date_list.append(H_row[0])
                H_opening_list.append(float(H_row[1]))
                H_closing_list.append(float(H_row[4]))

    
    #TSLA Percent Change Algorithm
    T_percent_increase_list = [(((T_closing_list[i]) - (T_opening_list[i]))/(T_opening_list[i])*100) for i in range (len(T_date_list))]

    #HAIL Percent Change Algorithm
    H_percent_increase_list = [(((H_closing_list[a]) - (H_opening_list[a]))/(H_opening_list[a])*100) for a in range (len(H_date_list))]
    
    graph_x_list_and_y_list(T_date_list, T_percent_increase_list, 'TSLA')
    graph_x_list_and_y_list(H_date_list, H_percent_increase_list, 'HAIL')
    update_and_show_graph()

main()
                
        
    
