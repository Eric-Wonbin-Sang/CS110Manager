from tkinter import *
from Classes.Scrape import Scrape
from selenium.webdriver.common.keys import Keys


class Display:

    def __init__(self):

        self.scrape = Scrape()
        self.root = Tk()
        self.root.attributes('-topmost', True)
        self.root.option_add('*Font', 'futura 12')
        self.root.title('Control')
        self.root.geometry('225x50')
        self.frame = Frame(self.root)
        self.is_checked = BooleanVar()
        self.checkbox = Checkbutton(self.root, variable = self.is_checked)
        self.checkbox.pack()
        self.pot_window = self.PotWindow(self.root, self.scrape)
        self.players_window = self.PlayersWindow(self.root, self.scrape)
        self.bets_window = self.BetsWindow(self.root, self.scrape)
        self.windows_list = [self.pot_window, self.players_window, self.bets_window]
        self.update()
        self.root.mainloop()

    def update(self):

        if self.is_checked.get() == 1:
            for win in self.windows_list:
                win.window.overrideredirect(True)
        else:
            for win in self.windows_list:
                win.window.overrideredirect(False)
        self.root.after(1000, self.update)


    class PotWindow:

        def __init__(self, root, scrape):

            self.scrape = scrape
            self.root = root
            self.window = Toplevel(self.root)
            self.window.title('Pot')
            self.window.attributes('-topmost', True)
            self.canvas = Canvas(self.window)
            self.canvas.grid(row = 0, column = 0, padx = (15, 15), pady = (5, 5))
            self.pot_bb = IntVar()
            self.pot_odds = DoubleVar()

            self.bb_label = Label(self.canvas, textvariable = self.pot_bb)
            self.bb_label.grid(row = 0, column = 0)

            self.bb_suffix_label = Label(self.canvas, text = ' bb pot')
            self.bb_suffix_label.grid(row = 0, column = 1)

            self.odds_label = Label(self.canvas, textvariable = self.pot_odds)
            self.odds_label.grid(row = 1, column = 0)

            self.odds_suffix_label = Label(self.canvas, text = ' % pot odds')
            self.odds_suffix_label.grid(row = 1, column = 1)

            self.update()

        def update(self):

            try:
                self.pot_bb.set(round(self.scrape.get_pot() / self.scrape.get_bigblind(), 1))
                self.pot_odds.set(self.scrape.get_potodds())
            except:
                pass

            self.root.after(1000, self.update)


    class PlayersWindow:

        def __init__(self, root, scrape):

            self.scrape = scrape
            self.players_dictionary_list = []
            self.bigblind = None
            self.root = root
            self.window = Toplevel(self.root)
            self.window.attributes('-topmost', True)
            self.window.title('Players')
            self.canvas = Canvas(self.window)
            self.canvas.grid(row = 0, column = 0, padx = (15, 15), pady = (5, 5))

            self.name_textbox = Text(self.canvas, width = 10, height = 20)
            self.name_textbox.grid(row = 0, column = 0)

            self.balance_textbox = Text(self.canvas, width = 20, height = 20)
            self.balance_textbox.grid(row = 0, column = 1)

            self.bb_balance_textbox = Text(self.canvas, width = 10, height = 20)
            self.bb_balance_textbox.grid(row = 0, column = 2)

            self.update()


        def update(self):

            try:
                self.players_dictionary_list = self.scrape.get_players()
                self.bigblind = self.scrape.get_bigblind()

                self.name_textbox.delete('1.0', END)
                self.balance_textbox.delete('1.0', END)
                self.bb_balance_textbox.delete('1.0', END)

                for index,name in enumerate(self.players_dictionary_list):
                    self.name_textbox.insert(END, self.players_dictionary_list[index]['name'] + '\n')
                    self.balance_textbox.insert(END, self.players_dictionary_list[index]['balance'] +'\n')
                    if isFloat(self.players_dictionary_list[index]['balance']):
                        balance_bb = float(self.players_dictionary_list[index]['balance']) / self.bigblind
                        balance_bb = round(balance_bb, 0)
                        self.bb_balance_textbox.insert(END, str(balance_bb) + ' bb\n')
                    else:
                        self.bb_balance_textbox.insert(END, '--\n')
            except:
                pass

            self.root.after(1000, self.update)


    class BetsWindow:

        def __init__(self, root, scrape):

            self.scrape = scrape
            self.root = root
            self.window = Toplevel(self.root)
            self.window.attributes('-topmost', True)
            self.window.title('Bets')

            self.custom_bets = 8
            self.custom_bets_list = []

            for bet in range(self.custom_bets):
                if bet <= 3:
                    self.custom_bets_list.append(self.CustomBet(bet, self.scrape, self.window, 0))
                else:
                    self.custom_bets_list.append(self.CustomBet(bet, self.scrape, self.window, 1))

            try:
                with open('custombets.txt') as f:
                    for custom_bet in self.custom_bets_list:
                        custom_bet.spinbox.delete(0, END)
                        custom_bet.spinbox.insert(END, f.readline().strip())
            except:
                pass

            self.update()

        def update(self):

            save_bets = open('custombets.txt', 'w')
            for custom_bet in self.custom_bets_list:
                save_bets.write(custom_bet.spinbox.get() + '\n')
            self.root.after(1000, self.update)


        class CustomBet:

            def __init__(self, col, scrape, window, bet_type):

                self.col = col
                self.scrape = scrape
                self.window = window
                self.canvas = Canvas(self.window)
                self.bet_type = bet_type
                self.canvas.grid(row = 0, column = self.col, padx = (5, 5), pady = (5, 5))
                self.spinbox = Spinbox(self.canvas, from_ = 1, to = 1000, width = 4)
                self.spinbox.grid(row = 0, column = 0)

                if self.bet_type == 0:
                    self.suffix = ' %'
                else:
                    self.suffix = ' bb'

                self.button = Button(self.canvas, height = 1, text = 'Bet' + self.suffix, command = lambda: self.custom_bet(self.scrape, self.spinbox.get(), self.bet_type))
                self.button.grid(row = 1, column = 0)

            def custom_bet(self, scrape, size, bet_type):
                try:
                    bet = scrape.driver.find_element_by_class_name('bet-input')
                    size = float(size)
                    calc = None
                    if bet_type == 0:
                        pot = scrape.get_pot()
                        size = size / 100
                        calc = size * pot
                    elif bet_type == 1:
                        bigblind = scrape.get_bigblind()
                        calc = size * bigblind
                    bet.clear()
                    bet.send_keys(str(calc))
                    bet.send_keys(Keys.RETURN)
                except:
                    pass


def isFloat(string):
    try:
        float(string)
        return True
    except ValueError:
        return False

def main():
    display = Display()


main()