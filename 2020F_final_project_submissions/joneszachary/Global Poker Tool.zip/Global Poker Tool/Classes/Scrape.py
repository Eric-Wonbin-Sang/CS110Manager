from selenium import webdriver


class Scrape:

    def __init__(self):

        self.chrome_options = webdriver.ChromeOptions()
        self.chrome_options.add_experimental_option("useAutomationExtension", False)
        self.chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        self.chrome_options.add_argument("--start-maximized")


        self.driver = webdriver.Chrome(executable_path =r'./chromedriver.exe', options = self.chrome_options)
        self.driver.get('https://play.globalpoker.com')


    def get_pot(self):

        potsize = self.driver.find_element_by_class_name('amount').text
        potsize = potsize.replace(',', '')

        return float(potsize)

    def get_potodds(self):

        call = self.driver.find_element_by_xpath('//*[@class="user-actions"]/div[4]/span[1]').text
        call = call.replace(',', '').replace(' ', '')

        if call:
            call = float(call)
            potodds = round((call / (self.get_pot() + call)) * 100, 1)
            return potodds

        else:
            return '--'

    def get_players(self):

        player_balances_list = []
        player_balances_scraped = self.driver.find_elements_by_class_name('seat-balance')

        for i in range(len(player_balances_scraped)):
            player_balances_list.append(player_balances_scraped[i].text.replace('SC ', '').replace(',', ''))
        map(float, player_balances_scraped)

        players_list = []
        players_scraped = self.driver.find_elements_by_class_name('player-name')
        for name in players_scraped:
            players_list.append(name.text[:4])

        player_dictionary_list = []
        for index, player in enumerate(players_list):
            player_dictionary_list.append({'name': players_list[index], 'balance': player_balances_list[index]})
        return player_dictionary_list

    def get_bigblind(self):

        bigblind = self.driver.find_element_by_class_name('table-blinds-value').text
        bigblind = bigblind[bigblind.index("/") + 1:]
        bigblind = bigblind.replace(',', '')
        return float(bigblind)