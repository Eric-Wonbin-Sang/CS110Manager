from graphics import *

def main():
    win= GraphWin("Draw a Triangle",300,300)
    win.setCoords(0.0, 0.0, 10.0, 10.0)
    instructions = Text(Point(5,0.5),"Click on three points")
    instructions.draw(win)

    #get and draw three vertices of triangle
    p1=win.getMouse()
    p1.draw(win)
    p2 = win.getMouse()
    p2.draw(win)
    p3 = win.getMouse()
    p3.draw(win)

    #Use polygon object to draw triangle
    triangle = Polygon(p1,p2,p3)
    triangle.draw(win)

    instructions.setText("Here is your triangle.")

main()