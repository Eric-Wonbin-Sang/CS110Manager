import csv
import matplotlib.pyplot as plt

label_list = [
    "Coca-Cola",
    "PepsiCo",
    "Nestlé"
]
csv_path_list = [
    "C:/Users/Nate Gee/Desktop/Stevens/CS 110/Final Project/2020.06.01 - 2020.09.29 KO.csv",
    "C:/Users/Nate Gee/Desktop/Stevens/CS 110/Final Project/2020.06.01 - 2020.09.29 PEP.csv",
    "C:/Users/Nate Gee/Desktop/Stevens/CS 110/Final Project/2020.06.01 - 2020.09.29 NSRGY.csv"
]
csv_path_list_2 = [
    "C:/Users/Nate Gee/Desktop/Stevens/CS 110/Final Project/2020.06.01 - 2020.09.29 KO.csv",
    "C:/Users/Nate Gee/Desktop/Stevens/CS 110/Final Project/2020.06.01 - 2020.09.29 PEP.csv"
]
csv_path_list_3 = [
    "C:/Users/Nate Gee/Desktop/Stevens/CS 110/Final Project/2020.06.01 - 2020.09.29 KO.csv",
    "C:/Users/Nate Gee/Desktop/Stevens/CS 110/Final Project/2020.06.01 - 2020.09.29 NSRGY.csv"
]
csv_path_list_4 = [
    "C:/Users/Nate Gee/Desktop/Stevens/CS 110/Final Project/2020.06.01 - 2020.09.29 PEP.csv",
    "C:/Users/Nate Gee/Desktop/Stevens/CS 110/Final Project/2020.06.01 - 2020.09.29 NSRGY.csv"
]

def just_coke():
    date_list = []
    price_list = []
    with open(csv_path_list[0]) as csv_file:
        for row in list(csv.reader(csv_file))[1:]:
            date_list.append(row[0])
            price_list.append(float(row[4]))

        plt.plot(date_list, price_list, label=label_list[0])

    plt.xlabel("Date")
    plt.ylabel("Closing Value")
    plt.title("Coca-Cola Stock Throughout The Summer of the Pandemic \n"
              "From 6/02/20 to 9/29/20")
    plt.xticks(rotation=90)
    plt.legend(loc='upper left')
    plt.show()

def just_pepsi():
    date_list = []
    price_list = []
    with open(csv_path_list[1]) as csv_file:
        for row in list(csv.reader(csv_file))[1:]:
            date_list.append(row[0])
            price_list.append(float(row[4]))

        plt.plot(date_list, price_list, label=label_list[1])

    plt.xlabel("Date")
    plt.ylabel("Closing Value")
    plt.title("PespsiCo Stock Throughout The Summer of the Pandemic \n"
              "From 6/02/20 to 9/29/20")
    plt.xticks(rotation=90)
    plt.legend(loc='upper left')
    plt.show()

def just_nestle():
    date_list = []
    price_list = []
    with open(csv_path_list[2]) as csv_file:
        for row in list(csv.reader(csv_file))[1:]:
            date_list.append(row[0])
            price_list.append(float(row[4]))

        plt.plot(date_list, price_list, label=label_list[2])

    plt.xlabel("Date")
    plt.ylabel("Closing Value")
    plt.title("Nestlé Stock Throughout The Summer of the Pandemic \n"
              "From 6/02/20 to 9/29/20")
    plt.xticks(rotation=90)
    plt.legend(loc='upper left')
    plt.show()

def coke_pepsi():
    count = 0
    for csv_path in csv_path_list_2:
        date_list = []
        price_list = []
        with open(csv_path) as csv_file:
            for row in list(csv.reader(csv_file))[1:]:
                date_list.append(row[0])
                price_list.append(float(row[4]))

            plt.plot(date_list, price_list, label=label_list[count])
            count = count + 1

    plt.xlabel("Date")
    plt.ylabel("Closing Value")
    plt.title("Coca-Cola and PepsiCo Stock Throughout The Summer of the Pandemic \n"
              "From 6/02/20 to 9/29/20")
    plt.xticks(rotation=90)
    plt.legend(loc='upper left')
    plt.show()

def coke_Nestlé():
    count = 0
    for csv_path in csv_path_list_3:
        date_list = []
        price_list = []
        with open(csv_path) as csv_file:
            for row in list(csv.reader(csv_file))[1:]:
                date_list.append(row[0])
                price_list.append(float(row[4]))

            plt.plot(date_list, price_list, label=label_list[count])
            count = count + 2
    plt.xlabel("Date")
    plt.ylabel("Closing Value")
    plt.title("Coca-Cola and Nestlé Stock Throughout The Summer of the Pandemic \n"
              "From 6/02/20 to 9/29/20")
    plt.xticks(rotation=90)
    plt.legend(loc='upper left')
    plt.show()

def pepsi_Nestlé():
    count = 1
    for csv_path in csv_path_list_4:
        date_list = []
        price_list = []
        with open(csv_path) as csv_file:
            for row in list(csv.reader(csv_file))[1:]:
                date_list.append(row[0])
                price_list.append(float(row[4]))

            plt.plot(date_list, price_list, label=label_list[count])
            count = count + 1

    plt.xlabel("Date")
    plt.ylabel("Closing Value")
    plt.title("PepsiCo and Nestlé Stock Throughout The Summer of the Pandemic \n"
              "From 6/02/20 to 9/29/20")
    plt.xticks(rotation=90)
    plt.legend(loc='upper left')
    plt.show()

def all_three():
    count = 0
    for csv_path in csv_path_list:
        date_list = []
        price_list = []
        with open(csv_path) as csv_file:
            for row in list(csv.reader(csv_file))[1:]:
                date_list.append(row[0])
                price_list.append(float(row[4]))

            plt.plot(date_list, price_list, label=label_list[count])
            count = count + 1

    plt.xlabel("Date")
    plt.ylabel("Closing Value")
    plt.title("Non-Alcholic Beverage Industry Throughout the Pandemic \n"
              "From 6/02/20 to 9/29/20")
    plt.xticks(rotation=90)
    plt.legend(loc='upper left')
    plt.grid
    plt.show()


def main():
    print("This program compares the stock prices of Coca-Cola, Pepsi, and Nestle from 6/02/2020 till 9/29/20 \n")
    valid_inputs = [1, 2, 3, 4, 5, 6, 7]

    selection = False
    while not selection:
        print("To just see Coca-Cola enter 1\n"
              "To just see Pepsi enter 2 \n"
              "To just see Nestlé enter 3 \n"
              "To compare Coca-Cola and Pepsi enter 4 \n"
              "To compare Coca-Cola and Nestlé enter 5 \n"
              "To compare Pepsi and Nestlé enter 6 \n"
              "To compare Coca-Cola, Pepsi, and Nestlé enter 7 \n")
        try:
            value = int(input("Please make a selection: "))
            for i in valid_inputs:
                if i == value:
                    selection = True
            if not selection:
                print("That is not a valid entry. Valid values are: 1,2,3,4,5,6,7\n")
                print("Please try again\n")
        except ValueError:
            print("That is not a valid entry. Valid values are: 1,2,3,4,5,6,7\n")
            print("Please try again\n")

    if value == 1:
        just_coke()
    elif value == 2:
        just_pepsi()
    elif value == 3:
        just_nestle()
    elif value == 4:
        coke_pepsi()
    elif value == 5:
        coke_Nestlé()
    elif value == 6:
        pepsi_Nestlé()
    elif value == 7:
        all_three()


main()