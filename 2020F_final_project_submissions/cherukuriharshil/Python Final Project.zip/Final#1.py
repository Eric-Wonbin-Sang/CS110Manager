import csv
import datetime as dt
import matplotlib.pyplot as plt
from matplotlib import style
import pandas_datareader.data as web

def healthcare():
    print("(Fund/ETF: IDNA)")
    print("In this program you will be able to look at data starting from one date to a another date in the")
    print("range starting from 2020-03-02 to 2020-10-30 ")
    num_of_months = 0
    total_diff_healthcare = 0
    total_perc_healthcare = 0
    list_day_1 = ['']
    list_day_2 = ['']
    with open('Healthcare.csv', 'r') as file_1:
        reader_1 = csv.DictReader(file_1)

        healthcare_input_1 = str(input("What is the first day you want to look at? (Range: 2020-03-02 to 2020-10-30): "))
        healthcare_input_2 = str(input("What is the second day you want to look at? (Range: 2020-03-02 to 2020-10-30): "))
        print()

        for row in reader_1:
            temp_date = str(row['Date'])
            x = float(row['Open'])
            y = float(row['Close'])
            diff_healthcare = y - x
            percent_diff_1 = (y - x) / x
            total_diff_healthcare += diff_healthcare
            total_perc_healthcare += percent_diff_1
            num_of_months += 1

            if healthcare_input_1.strip() == temp_date.strip():
                print("----------------------------Printing data for date 1----------------------------")
                print(row)
                print("The Date, Open, & Close for this day: ", row['Date'], row['Open'], row['Close'])
                if x > y:
                    print("The sector experienced a downward trend on this day")
                elif y > x:
                    print("The sector experienced a upward trend this day")
                print("The difference between the closing and opening price on this day is", diff_healthcare)
                print("The percent growth/decline of the sector for this day is %", percent_diff_1 * 100)
                print("The average points growth/decline of the sector until this point is",
                      (total_diff_healthcare / num_of_months), "points")
                print("The average percent growth/decline of the sector until this point is %",
                      (total_perc_healthcare / num_of_months) * 100)
                print()

                list_day_1[0] = row['Date']
                list_day_1.append(row['Open'])
                list_day_1.append(row['Close'])
                list_day_1.append(diff_healthcare)
                list_day_1.append((percent_diff_1 * 100))
                list_day_1.append((total_diff_healthcare / num_of_months))
                list_day_1.append(((total_perc_healthcare / num_of_months) * 100))

                continue

            elif healthcare_input_2.strip() == temp_date.strip():
                print("----------------------------Printing data for date 2----------------------------")
                print(row)
                print("The Date, Open, & Close for this day: ", row['Date'], row['Open'], row['Close'])
                if x > y:
                    print("The sector experienced a downward trend on this day")
                elif y > x:
                    print("The sector experienced a upward trend this day")
                print("The difference between the closing and opening price on this day is", diff_healthcare)
                print("The percent growth/decline of the sector for this day is %", percent_diff_1 * 100)
                print("The average points growth/decline of the sector until this point is",
                      (total_diff_healthcare / num_of_months), "points")
                print("The average percent growth/decline of the sector until this point is %",
                      (total_perc_healthcare / num_of_months) * 100)
                print()

                list_day_2[0] = row['Date']
                list_day_2.append(row['Open'])
                list_day_2.append(row['Close'])
                list_day_2.append(diff_healthcare)
                list_day_2.append((percent_diff_1 * 100))
                list_day_2.append((total_diff_healthcare / num_of_months))
                list_day_2.append(((total_perc_healthcare / num_of_months) * 100))

                break

        print("If there is no data printing for your day, then the date you entered was either not a weekday, a national holiday, or an input out of bounds ")
        print()

        print("__________________ Summary __________________")
        if list_day_1[0] != '' and list_day_2[0] != '':
            if list_day_1[1] > list_day_2[1]:
                print("DAY 1 had a higher OPEN: ", list_day_1[1])
            else:
                print("DAY 2 had a higher OPEN: ", list_day_2[1])
            if list_day_1[2] > list_day_2[2]:
                print("DAY 1 had a higher CLOSE: ", list_day_1[2])
            else:
                print("DAY 2 had a higher CLOSE: ", list_day_2[2])
            if list_day_1[3] > list_day_2[3]:
                print("DAY 1 had a higher difference between the closing and opening price, meaning DAY 1 had higher volatility: ", list_day_1[3])
            else:
                print("DAY 2 had more difference between the closing and opening price, meaning DAY 2 had higher volatility: ", list_day_2[3])
            if list_day_1[4] > list_day_2[4]:
                print("DAY 1 had a higher percent growth/decline on this day: %", list_day_1[4])
            else:
                print("DAY 2 had a higher percent growth/decline on this day: %", list_day_2[4])

            print('OPEN of Day 2 - OPEN of Day 1 = ', float(list_day_2[1]) - float(list_day_1[1])),
            print('CLOSE of Day 2 - CLOSE of Day 1 = ', float(list_day_2[2]) - float(list_day_1[2]))

        elif list_day_1[0] != '':
            print('Day 1 => Date: ', list_day_1[0], ' Open: ', list_day_1[1], ' Close: ', list_day_1[2],
                  ' Difference: ', list_day_1[3], ' Percentage: ', list_day_1[6])
        elif list_day_2[0] != '':
            print('Day 2 => Date: ', list_day_2[0], ' Open: ', list_day_2[1], ' Close: ', list_day_2[2],
                  ' Difference: ', list_day_2[3], ' Percentage: ', list_day_2[6])
        else:
            print('No Results found for both dates')

    style.use("ggplot")
    start = dt.datetime(2020, 3, 2)
    end = dt.datetime(2020, 10, 30)
    df = web.get_data_yahoo("IDNA", start, end)
    df["Close"].plot()
    plt.show()

def technology():
    print("(Fund/ETF: XLK)")
    print("In this program you will be able to look at data starting from one date to a another date in the")
    print("range starting from 2020-03-02 to 2020-10-30 ")
    num_of_months_2 = 0
    total_diff_tech = 0
    total_perc_tech = 0
    list_day_1 = ['']
    list_day_2 = ['']
    with open('Technology.csv', 'r') as file_2:
        reader_2 = csv.DictReader(file_2)

        technology_input_1 = str(input("What is the first day you want to look at? (Range: 2020-03-02 to 2020-10-30): "))
        technology_input_2 = str(input("What is the second day you want to look at? (Range: 2020-03-02 to 2020-10-30): "))
        print()

        for row1 in reader_2:
            temp_date = str(row1['Date'])
            x = float(row1['Open'])
            y = float(row1['Close'])
            diff_tech = y - x
            percent_diff_2 = (y - x) / x
            total_diff_tech += diff_tech
            total_perc_tech += percent_diff_2
            num_of_months_2 += 1

            if technology_input_1.strip() == temp_date.strip():
                print("----------------------------Printing data for date 1----------------------------")
                print(row1)
                print("The Date, Open, & Close for this day: ", row1['Date'], row1['Open'], row1['Close'])
                if x > y:
                    print("The sector experienced a downward trend on this day")
                elif y > x:
                    print("The sector experienced a upward trend this day")
                print("The difference between the closing and opening price on this day is", diff_tech)
                print("The percent growth/decline of the sector for this day is %", percent_diff_2 * 100)
                print("The average points growth/decline of the sector until this point is",
                      (total_diff_tech / num_of_months_2), "points")
                print("The average percent growth/decline of the sector until this point is %",
                      (total_perc_tech / num_of_months_2) * 100)
                print()

                list_day_1[0] = row1['Date']
                list_day_1.append(row1['Open'])
                list_day_1.append(row1['Close'])
                list_day_1.append(diff_tech)
                list_day_1.append((percent_diff_2 * 100))
                list_day_1.append((total_diff_tech / num_of_months_2))
                list_day_1.append(((total_perc_tech / num_of_months_2) * 100))

                continue

            elif technology_input_2.strip() == temp_date.strip():
                print("----------------------------Printing data for date 2----------------------------")
                print(row1)
                print("The Date, Open, & Close for this day: ", row1['Date'], row1['Open'], row1['Close'])
                if x > y:
                    print("The sector experienced a downward trend on this day")
                elif y > x:
                    print("The sector experienced a upward trend this day")
                print("The difference between the closing and opening price on this day is", diff_tech)
                print("The percent growth/decline of the sector for this day is %", percent_diff_2 * 100)
                print("The average points growth/decline of the sector until this point is",
                      (total_diff_tech / num_of_months_2), "points")
                print("The average percent growth/decline of the sector until this point is %",
                      (total_perc_tech / num_of_months_2) * 100)
                print()

                list_day_2[0] = row1['Date']
                list_day_2.append(row1['Open'])
                list_day_2.append(row1['Close'])
                list_day_2.append(diff_tech)
                list_day_2.append((percent_diff_2 * 100))
                list_day_2.append((total_diff_tech / num_of_months_2))
                list_day_2.append(((total_perc_tech / num_of_months_2) * 100))

                break

        print("If there is no data printing for your day, then the date you entered was either not a weekday, a national holiday, or an input out of bounds ")
        print()

        print("__________________ Summary __________________")
        if list_day_1[0] != '' and list_day_2[0] != '':
            if list_day_1[1] > list_day_2[1]:
                print("DAY 1 had a higher OPEN ", list_day_1[1])
            else:
                print("DAY 2 had a higher OPEN ", list_day_2[1])
            if list_day_1[2] > list_day_2[2]:
                print("DAY 1 had a higher CLOSE ", list_day_1[2])
            else:
                print("DAY 2 had a higher CLOSE ", list_day_2[2])
            if list_day_1[3] > list_day_2[3]:
                print(
                    "DAY 1 had a higher difference between the closing and opening price, meaning DAY 1 had higher volatility ",
                    list_day_1[3])
            else:
                print(
                    "DAY 2 had more difference between the closing and opening price, meaning DAY 2 had higher volatility ",
                    list_day_2[3])
            if list_day_1[4] > list_day_2[4]:
                print("DAY 1 had a higher percent growth/decline on this day %", list_day_1[4])
            else:
                print("DAY 2 had a higher percent growth/decline on this day %", list_day_2[4])

            print('OPEN of Day 2 - OPEN of Day 1 = ', float(list_day_2[1]) - float(list_day_1[1])),
            print('CLOSE of Day 2 - CLOSE of Day 1 = ', float(list_day_2[2]) - float(list_day_1[2]))

        elif list_day_1[0] != '':
            print('Day 1 => Date: ', list_day_1[0], ' Open: ', list_day_1[1], ' Close: ', list_day_1[2],
                  ' Difference: ', list_day_1[3], ' Percentage: ', list_day_1[6])
        elif list_day_2[0] != '':
            print('Day 2 => Date: ', list_day_2[0], ' Open: ', list_day_2[1], ' Close: ', list_day_2[2],
                  ' Difference: ', list_day_2[3], ' Percentage: ', list_day_2[6])
        else:
            print('No Results found for both dates')

    style.use("ggplot")
    start = dt.datetime(2020, 3, 2)
    end = dt.datetime(2020, 10, 30)
    df = web.get_data_yahoo("XLK", start, end)
    df["Close"].plot()
    plt.show()

def pharmaceuticals():
    print("(Fund/ETF: XPH)")
    print("In this program you will be able to look at data starting from one date to a another date in the")
    print("range starting from 2020-03-02 to 2020-10-30 ")
    num_of_months_3 = 0
    total_diff_pharma = 0
    total_perc_pharma = 0
    list_day_1 = ['']
    list_day_2 = ['']
    with open('Pharmaceuticals.csv', 'r') as file_3:
        reader_3 = csv.DictReader(file_3)

        pharmaceuticals_input_1 = str(input("What is the first day you want to look at? (Range: 2020-03-02 to 2020-10-30): "))
        pharmaceuticals_input_2 = str(input("What is the second day you want to look at? (Range: 2020-03-02 to 2020-10-30): "))
        print()

        for row2 in reader_3:
            temp_date = str(row2['Date'])
            x = float(row2['Open'])
            y = float(row2['Close'])
            diff_pharma = y - x
            percent_diff_3 = (y - x) / x
            total_diff_pharma += diff_pharma
            total_perc_pharma += percent_diff_3
            num_of_months_3 += 1

            if pharmaceuticals_input_1.strip() == temp_date.strip():
                print("----------------------------Printing data for date 1----------------------------")
                print(row2)
                print("The Date, Open, & Close for this day: ", row2['Date'], row2['Open'], row2['Close'])
                if x > y:
                    print("The sector experienced a downward trend on this day")
                elif y > x:
                    print("The sector experienced a upward trend this day")
                print("The difference between the closing and opening price on this day is", diff_pharma)
                print("The percent growth/decline of the sector for this day is %", percent_diff_3 * 100)
                print("The average points growth/decline of the sector until this point is",
                      (total_diff_pharma / num_of_months_3), "points")
                print("The average percent growth/decline of the sector until this point is %",
                      (total_perc_pharma / num_of_months_3) * 100)
                print()

                list_day_1[0] = row2['Date']
                list_day_1.append(row2['Open'])
                list_day_1.append(row2['Close'])
                list_day_1.append(diff_pharma)
                list_day_1.append((percent_diff_3 * 100))
                list_day_1.append((total_diff_pharma / num_of_months_3))
                list_day_1.append(((total_perc_pharma / num_of_months_3) * 100))

                continue

            elif pharmaceuticals_input_2.strip() == temp_date.strip():
                print("----------------------------Printing data for date 2----------------------------")
                print(row2)
                print("The Date, Open, & Close for this day: ", row2['Date'], row2['Open'], row2['Close'])
                if x > y:
                    print("The sector experienced a downward trend on this day")
                elif y > x:
                    print("The sector experienced a upward trend this day")
                print("The difference between the closing and opening price on this day is", diff_pharma)
                print("The percent growth/decline of the sector for this day is %", percent_diff_3 * 100)
                print("The average points growth/decline of the sector until this point is",
                      (total_diff_pharma / num_of_months_3), "points")
                print("The average percent growth/decline of the sector until this point is %",
                      (total_perc_pharma / num_of_months_3) * 100)
                print()

                list_day_2[0] = row2['Date']
                list_day_2.append(row2['Open'])
                list_day_2.append(row2['Close'])
                list_day_2.append(diff_pharma)
                list_day_2.append((percent_diff_3 * 100))
                list_day_2.append((total_diff_pharma / num_of_months_3))
                list_day_2.append(((total_perc_pharma / num_of_months_3) * 100))

                break

        print("If there is no data printing for your day, then the date you entered was either not a weekday, a national holiday, or an input out of bounds ")
        print()

        print("__________________ Summary __________________")
        if list_day_1[0] != '' and list_day_2[0] != '':
            if list_day_1[1] > list_day_2[1]:
                print("DAY 1 had a higher OPEN ", list_day_1[1])
            else:
                print("DAY 2 had a higher OPEN ", list_day_2[1])
            if list_day_1[2] > list_day_2[2]:
                print("DAY 1 had a higher CLOSE ", list_day_1[2])
            else:
                print("DAY 2 had a higher CLOSE ", list_day_2[2])
            if list_day_1[3] > list_day_2[3]:
                print(
                    "DAY 1 had a higher difference between the closing and opening price, meaning DAY 1 had higher volatility ",
                    list_day_1[3])
            else:
                print(
                    "DAY 2 had more difference between the closing and opening price, meaning DAY 2 had higher volatility ",
                    list_day_2[3])
            if list_day_1[4] > list_day_2[4]:
                print("DAY 1 had a higher percent growth/decline on this day %", list_day_1[4])
            else:
                print("DAY 2 had a higher percent growth/decline on this day %", list_day_2[4])

            print('OPEN of Day 2 - OPEN of Day 1 = ', float(list_day_2[1]) - float(list_day_1[1])),
            print('CLOSE of Day 2 - CLOSE of Day 1 = ', float(list_day_2[2]) - float(list_day_1[2]))

        elif list_day_1[0] != '':
            print('Day 1 => Date: ', list_day_1[0], ' Open: ', list_day_1[1], ' Close: ', list_day_1[2],
                  ' Difference: ', list_day_1[3], ' Percentage: ', list_day_1[6])
        elif list_day_2[0] != '':
            print('Day 2 => Date: ', list_day_2[0], ' Open: ', list_day_2[1], ' Close: ', list_day_2[2],
                  ' Difference: ', list_day_2[3], ' Percentage: ', list_day_2[6])
        else:
            print('No Results found for both dates')

    style.use("ggplot")
    start = dt.datetime(2020, 3, 2)
    end = dt.datetime(2020, 10, 30)
    df = web.get_data_yahoo("XPH", start, end)
    df["Close"].plot()
    plt.show()


def financials():
    print("(Fund/ETF: VFH)")
    print("In this program you will be able to look at data starting from one date to a another date in the")
    print("range starting from 2020-03-02 to 2020-10-30 ")
    num_of_months_4 = 0
    total_diff_financials = 0
    total_perc_financials = 0
    list_day_1 = ['']
    list_day_2 = ['']
    with open('Financials.csv', 'r') as file_4:
        reader_4 = csv.DictReader(file_4)

        financials_input_1 = str(input("What is the first day you want to look at? (Range: 2020-03-02 to 2020-10-30): "))
        financials_input_2 = str(input("What is the second day you want to look at? (Range: 2020-03-02 to 2020-10-30): "))
        print()

        for row3 in reader_4:
            temp_date = str(row3['Date'])
            x = float(row3['Open'])
            y = float(row3['Close'])
            diff_financials = y - x
            percent_diff_4 = (y - x) / x
            total_diff_financials += diff_financials
            total_perc_financials += percent_diff_4
            num_of_months_4 += 1

            if financials_input_1.strip() == temp_date.strip():
                print("----------------------------Printing data for date 1----------------------------")
                print(row3)
                print("The Date, Open, & Close for this day: ", row3['Date'], row3['Open'], row3['Close'])
                if x > y:
                    print("The sector experienced a downward trend on this day")
                elif y > x:
                    print("The sector experienced a upward trend this day")
                print("The difference between the closing and opening price on this day is", diff_financials)
                print("The percent growth/decline of the sector for this day is %", percent_diff_4 * 100)
                print("The average points growth/decline of the sector until this point is",
                      (total_diff_financials / num_of_months_4), "points")
                print("The average percent growth/decline of the sector until this point is %",
                      (total_perc_financials / num_of_months_4) * 100)
                print()

                list_day_1[0] = row3['Date']
                list_day_1.append(row3['Open'])
                list_day_1.append(row3['Close'])
                list_day_1.append(diff_financials)
                list_day_1.append((percent_diff_4 * 100))
                list_day_1.append((total_diff_financials / num_of_months_4))
                list_day_1.append(((total_perc_financials / num_of_months_4) * 100))

                continue

            elif financials_input_2.strip() == temp_date.strip():
                print("----------------------------Printing data for date 2----------------------------")
                print(row3)
                print("The Date, Open, & Close for this day: ", row3['Date'], row3['Open'], row3['Close'])
                if x > y:
                    print("The sector experienced a downward trend on this day")
                elif y > x:
                    print("The sector experienced a upward trend this day")
                print("The difference between the closing and opening price on this day is", diff_financials)
                print("The percent growth/decline of the sector for this day is %", percent_diff_4 * 100)
                print("The average points growth/decline of the sector until this point is",
                      (total_diff_financials / num_of_months_4), "points")
                print("The average percent growth/decline of the sector until this point is %",
                      (total_perc_financials / num_of_months_4) * 100)
                print()

                list_day_2[0] = row3['Date']
                list_day_2.append(row3['Open'])
                list_day_2.append(row3['Close'])
                list_day_2.append(diff_financials)
                list_day_2.append((percent_diff_4 * 100))
                list_day_2.append((total_diff_financials / num_of_months_4))
                list_day_2.append(((total_perc_financials / num_of_months_4) * 100))

                break

        print("If there is no data printing for your day, then the date you entered was either not a weekday, a national holiday, or an input out of bounds ")
        print()

        print("__________________ Summary __________________")
        if list_day_1[0] != '' and list_day_2[0] != '':
            if list_day_1[1] > list_day_2[1]:
                print("DAY 1 had a higher OPEN ", list_day_1[1])
            else:
                print("DAY 2 had a higher OPEN ", list_day_2[1])
            if list_day_1[2] > list_day_2[2]:
                print("DAY 1 had a higher CLOSE ", list_day_1[2])
            else:
                print("DAY 2 had a higher CLOSE ", list_day_2[2])
            if list_day_1[3] > list_day_2[3]:
                print(
                    "DAY 1 had a higher difference between the closing and opening price, meaning DAY 1 had higher volatility ",
                    list_day_1[3])
            else:
                print(
                    "DAY 2 had more difference between the closing and opening price, meaning DAY 2 had higher volatility ",
                    list_day_2[3])
            if list_day_1[4] > list_day_2[4]:
                print("DAY 1 had a higher percent growth/decline on this day %", list_day_1[4])
            else:
                print("DAY 2 had a higher percent growth/decline on this day %", list_day_2[4])

            print('OPEN of Day 2 - OPEN of Day 1 = ', float(list_day_2[1]) - float(list_day_1[1])),
            print('CLOSE of Day 2 - CLOSE of Day 1 = ', float(list_day_2[2]) - float(list_day_1[2]))

        elif list_day_1[0] != '':
            print('Day 1 => Date: ', list_day_1[0], ' Open: ', list_day_1[1], ' Close: ', list_day_1[2],
                  ' Difference: ', list_day_1[3], ' Percentage: ', list_day_1[6])
        elif list_day_2[0] != '':
            print('Day 2 => Date: ', list_day_2[0], ' Open: ', list_day_2[1], ' Close: ', list_day_2[2],
                  ' Difference: ', list_day_2[3], ' Percentage: ', list_day_2[6])
        else:
            print('No Results found for both dates')

    style.use("ggplot")
    start = dt.datetime(2020, 3, 2)
    end = dt.datetime(2020, 10, 30)
    df = web.get_data_yahoo("VFH", start, end)
    df["Close"].plot()
    plt.show()


def oil():
    print("(Fund/ETF: HUC.TO)")
    print("In this program you will be able to look at data starting from one date to a another date in the")
    print("range starting from 2020-03-02 to 2020-10-30 ")
    num_of_months_5 = 0
    total_diff_oil = 0
    total_perc_oil = 0
    list_day_1 = ['']
    list_day_2 = ['']
    with open('Crude Oil.csv', 'r') as file_5:
        reader_5 = csv.DictReader(file_5)

        oil_input_1 = str(input("What is the first day you want to look at? (Range: 2020-03-02 to 2020-10-30): "))
        oil_input_2 = str(input("What is the second day you want to look at? (Range: 2020-03-02 to 2020-10-30): "))
        print()

        for row4 in reader_5:
            temp_date = str(row4['Date'])
            x = float(row4['Open'])
            y = float(row4['Close'])
            diff_oil = y - x
            percent_diff_5 = (y - x) / x
            total_diff_oil += diff_oil
            total_perc_oil += percent_diff_5
            num_of_months_5 += 1

            if oil_input_1.strip() == temp_date.strip():
                print("----------------------------Printing data for date 1----------------------------")
                print(row4)
                print("The Date, Open, & Close for this day: ", row4['Date'], row4['Open'], row4['Close'])
                if x > y:
                    print("The sector experienced a downward trend on this day")
                elif y > x:
                    print("The sector experienced a upward trend this day")
                print("The difference between the closing and opening price on this day is", diff_oil)
                print("The percent growth/decline of the sector for this day is %", percent_diff_5 * 100)
                print("The average points growth/decline of the sector until this point is",
                      (total_diff_oil / num_of_months_5), "points")
                print("The average percent growth/decline of the sector until this point is %",
                      (total_perc_oil / num_of_months_5) * 100)
                print()

                list_day_1[0] = row4['Date']
                list_day_1.append(row4['Open'])
                list_day_1.append(row4['Close'])
                list_day_1.append(diff_oil)
                list_day_1.append((percent_diff_5 * 100))
                list_day_1.append((total_diff_oil / num_of_months_5))
                list_day_1.append(((total_perc_oil / num_of_months_5) * 100))

                continue

            elif oil_input_2.strip() == temp_date.strip():
                print("----------------------------Printing data for date 2----------------------------")
                print(row4)
                print("The Date, Open, & Close for this day: ", row4['Date'], row4['Open'], row4['Close'])
                if x > y:
                    print("The sector experienced a downward trend on this day")
                elif y > x:
                    print("The sector experienced a upward trend this day")
                print("The difference between the closing and opening price on this day is", diff_oil)
                print("The percent growth/decline of the sector for this day is %", percent_diff_5 * 100)
                print("The average points growth/decline of the sector until this point is",
                      (total_diff_oil / num_of_months_5), "points")
                print("The average percent growth/decline of the sector until this point is %",
                      (total_perc_oil / num_of_months_5) * 100)
                print()

                list_day_2[0] = row4['Date']
                list_day_2.append(row4['Open'])
                list_day_2.append(row4['Close'])
                list_day_2.append(diff_oil)
                list_day_2.append((percent_diff_5 * 100))
                list_day_2.append((total_diff_oil / num_of_months_5))
                list_day_2.append(((total_perc_oil / num_of_months_5) * 100))

                break

        print("If there is no data printing for your day, then the date you entered was either not a weekday, a national holiday, or an input out of bounds ")
        print()

        print("__________________ Summary __________________")
        if list_day_1[0] != '' and list_day_2[0] != '':
            if list_day_1[1] > list_day_2[1]:
                print("DAY 1 had a higher OPEN ", list_day_1[1])
            else:
                print("DAY 2 had a higher OPEN ", list_day_2[1])
            if list_day_1[2] > list_day_2[2]:
                print("DAY 1 had a higher CLOSE ", list_day_1[2])
            else:
                print("DAY 2 had a higher CLOSE ", list_day_2[2])
            if list_day_1[3] > list_day_2[3]:
                print(
                    "DAY 1 had a higher difference between the closing and opening price, meaning DAY 1 had higher volatility ",
                    list_day_1[3])
            else:
                print(
                    "DAY 2 had more difference between the closing and opening price, meaning DAY 2 had higher volatility ",
                    list_day_2[3])
            if list_day_1[4] > list_day_2[4]:
                print("DAY 1 had a higher percent growth/decline on this day %", list_day_1[4])
            else:
                print("DAY 2 had a higher percent growth/decline on this day %", list_day_2[4])

            print('OPEN of Day 2 - OPEN of Day 1 = ', float(list_day_2[1]) - float(list_day_1[1])),
            print('CLOSE of Day 2 - CLOSE of Day 1 = ', float(list_day_2[2]) - float(list_day_1[2]))

        elif list_day_1[0] != '':
            print('Day 1 => Date: ', list_day_1[0], ' Open: ', list_day_1[1], ' Close: ', list_day_1[2],
                  ' Difference: ', list_day_1[3], ' Percentage: ', list_day_1[6])
        elif list_day_2[0] != '':
            print('Day 2 => Date: ', list_day_2[0], ' Open: ', list_day_2[1], ' Close: ', list_day_2[2],
                  ' Difference: ', list_day_2[3], ' Percentage: ', list_day_2[6])
        else:
            print('No Results found for both dates')

    style.use("ggplot")
    start = dt.datetime(2020, 3, 2)
    end = dt.datetime(2020, 10, 30)
    df = web.get_data_yahoo("HUC.TO", start, end)
    df["Close"].plot()
    plt.show()


def main():
    print("This program tries to help the user determine the best performing stocks from each sector")
    print("The sectors that are all analyzed within this program are healthcare, technology, "
          "pharmaceuticals, financials, and oil")
    user_input = str(input("Please type in the sector you want to look at (in lowercase): "))

    if user_input == 'healthcare':
        print()
        print("Thanks for choosing to look at the healthcare sector")
        print("Here is the daily data showcasing the general trend of the healthcare sector from 2020-03-02 to 2020-10-30")

        healthcare()

    elif user_input == 'technology':
        print()
        print("Thanks for choosing to look at the technology sector")
        print("Here is the daily data showcasing the general trend of the technology sector from 2020-03-02 to 2020-10-30")

        technology()

    elif user_input == 'pharmaceuticals':
        print()
        print("Thanks for choosing to look at the pharmaceutical sector")
        print("Here is the daily data showcasing the general trend of the pharmaceutical sector from 2020-03-02 to 2020-10-30")

        pharmaceuticals()

    elif user_input == 'financials':
        print()
        print("Thanks for choosing to look at the financial sector")
        print("Here is the daily data showcasing the general trend of the financial sector from 2020-03-02 to 2020-10-30")

        financials()

    elif user_input == 'oil':
        print()
        print("Thanks for choosing to look at the oil sector")
        print("Here is the daily data showcasing the general trend of the oil sector from 2020-03-02 to 2020-10-30")

        oil()

    else:
        print("Input is invalid, please rerun the program and enter a valid string input")


main()
