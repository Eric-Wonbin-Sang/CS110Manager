#CS110 FINAL
#I pledge my honor that I have abided by the Stevens Honor Code

import csv
import matplotlib.pyplot as plt

def get_ticker_from_file_path(file_path):
    return file_path.split(" ")[-1][:-4]

def graph_x_list_and_y_list(x_list, y_list, ticker):
    plt.plot(x_list, y_list, label=ticker)

def update_and_show_graph():
    plt.xlabel('Date')
    plt.ylabel('Percent Change')
    plt.xticks(rotation=90)
    plt.title('Percent Change SNAP vs S&P')
    plt.legend()
    plt.grid()
    plt.show()

def update_and_show_graph_snap():
    plt.xlabel('Date')
    plt.ylabel('Price')
    plt.xticks(rotation=90)
    plt.title('SNAP Share Price YTD')
    plt.grid()
    plt.show()

def update_and_show_graph_sp():
    plt.xlabel('Date')
    plt.ylabel('Price')
    plt.xticks(rotation=90)
    plt.title('S&P Share Price YTD')
    plt.grid()
    plt.show()

def main():
    #Volatility Comparison
    #SNAP code
    csv_file_path = 'C:\\Users\\jrotu\\Documents\\CS110\\CS110FINAL\\SNAP.csv'
    ticker = get_ticker_from_file_path(csv_file_path)
    date_list = []
    opening_list = []
    closing_list = []
    with open(csv_file_path) as csv_file:
        row_list = csv.reader(csv_file)
        for row_index, row in enumerate(row_list):
            if row_index != 0:
                date_list.append(row[0])
                opening_list.append(float(row[1]))
                closing_list.append(float(row[4]))
                
    percentage_change_list = [(((closing_list[i]) - (opening_list[i]))/(opening_list[i])*100) for i in range(len(date_list))]
    
    graph_x_list_and_y_list(date_list, percentage_change_list, 'SNAP Percent Change')    
    
    #S&P code

    csv_file_path_sp = 'C:\\Users\\jrotu\\Documents\\CS110\\CS110FINAL\\^GSPC.csv'
    tickersp = get_ticker_from_file_path(csv_file_path_sp)
    date_list_sp = []
    opening_list_sp = []
    closing_list_sp = []
    with open(csv_file_path_sp) as csv_file:
        row_list_sp = csv.reader(csv_file)
        for row_index_sp, row in enumerate(row_list_sp):
            if row_index_sp != 0:
                date_list_sp.append(row[0])
                opening_list_sp.append(float(row[1]))
                closing_list_sp.append(float(row[4]))

    percentage_change_list_sp = [(((closing_list_sp[i]) - (opening_list_sp[i]))/(opening_list_sp[i])*100) for i in range(len(date_list_sp))]
    
    graph_x_list_and_y_list(date_list_sp, percentage_change_list_sp, 'S&P Percent Change')    
    update_and_show_graph()
    ##############################################################

    #SNAP Price Change YTD code
    snap_price_change = [(closing_list[i]) for i in range(len(date_list))]
    graph_x_list_and_y_list(date_list, snap_price_change, 'SNAP Price Change')
    update_and_show_graph_snap()

    #S&P Price Change YTD code
    sp_price_change = [(closing_list_sp[i]) for i in range(len(date_list_sp))]
    graph_x_list_and_y_list(date_list_sp, sp_price_change, 'S&P Price Change')
    update_and_show_graph_sp()

main()    
