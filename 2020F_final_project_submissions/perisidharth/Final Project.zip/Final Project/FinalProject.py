#Sidharth Peri
#CS-110
#Final Project

#A program that plots a comparison of the bollinger bands and price trend for Amazon stock in 2019 and outputs a transaction table

import csv
import matplotlib.pyplot as plt
import pandas as pd

def get_date_and_closing_list(csv_file_path):
    date_list = []
    closing_list = []
    with open(csv_file_path) as csv_file:
        row_list = csv.reader(csv_file)
        for row_index, row in enumerate(row_list):
            if row_index != 0:
                date = row[0]
                close = float(row[4])
                date_list.append(date)
                closing_list.append(close)
    return date_list, closing_list

def get_moving_average_and_standard_deviation_list(csv_file_path):
    moving_avg_list = []
    standard_deviation_list = []
    df = pd.read_csv(csv_file_path)

    with open(csv_file_path) as csv_file:
        row_list = csv.reader(csv_file)
        for row_index, row in enumerate(row_list):
            if row_index != 0:
                df['MA'] = df['Close'].rolling(window=20).mean()
                moving_avg_list = df['MA'].tolist()
                df['STD'] = df['Close'].rolling(window=20).std()
                standard_deviation_list = df['STD'].tolist()

    return moving_avg_list, standard_deviation_list

def get_upper_and_lower_band_list(ma_list, std_list):
    upper_band = []
    lower_band = []

    length = len(ma_list)
    for row in range(length):
        upper_price = ma_list[row] + 2*std_list[row]
        upper_band.append(upper_price)
        lower_price = ma_list[row] - 2*std_list[row]
        lower_band.append(lower_price)
    return upper_band, lower_band

def graph_x_and_y_lists(x_list, y_list, ticker):
    plt.plot(x_list, y_list, label = ticker)

def update_and_show_graph():
    plt.xlabel('Date')
    plt.ylabel('Closing Price')
    plt.title('Amazon 2019 Bollinger Bands Analysis')
    plt.xticks(rotation = 90)
    plt.rc('xtick', labelsize=1)
    plt.legend()
    plt.grid()
    plt.show()

def get_transaction_days(csv_file_path, upper, lower):
    df = pd.read_csv(csv_file_path)
    df['Upper Band'], df['Lower Band'] = upper, lower
    df['Buy/Sell'] = 0
    for row in range(len(df)):
        if((df['Close'].iloc[row] < df['Lower Band'].iloc[row]) & (df['Close'].iloc[row-1] > df['Lower Band'].iloc[row-1])):
            pd.set_option('mode.chained_assignment', None)
            df['Buy/Sell'].iloc[row] = "Buy"

        elif((df['Close'].iloc[row] > df['Upper Band'].iloc[row]) & (df['Close'].iloc[row-1] < df['Upper Band'].iloc[row-1])):
            pd.set_option('mode.chained_assignment', None)
            df['Buy/Sell'].iloc[row] = "Sell"

    dropIndexes = df[df['Buy/Sell'] == 0].index
    df.drop(dropIndexes, inplace = True)

    return (df[['Date', 'Close', 'Upper Band', 'Lower Band', 'Buy/Sell']])

def main():
    csv_file_path = 'C:/Users/Sid Peri/Desktop/Stevens Classes/CS-110/Final Project/AMZN.csv'

    date_list, close_list = get_date_and_closing_list(csv_file_path)
    moving_average, standard_deviation = get_moving_average_and_standard_deviation_list(csv_file_path)
    upper_band, lower_band = get_upper_and_lower_band_list(moving_average, standard_deviation)

    graph_x_and_y_lists(date_list, close_list, 'AMZN Closing Price')
    graph_x_and_y_lists(date_list, upper_band, 'Upper Band')
    graph_x_and_y_lists(date_list, lower_band, 'Lower Band')

    update_and_show_graph()

    transaction_table = get_transaction_days(csv_file_path, upper_band, lower_band)
    print("Amazon's 2019 Bollinger Bands Transaction Table: \n", transaction_table)

main()






