import csv
def finding_max(total_change_list, peak):
    global maximum, num
    for row_index, row in enumerate(total_change_list, start = 3):
        if row == peak:
            num = row_index
            maximum = peak

    result = county_enum(num, maximum)
    print("\nThe largest percent increase:", result[1]*100, "%", "happened in:", result[0])

def finding_min(total_change_list, bottom):
    global minimum, place
    for row_index, row in enumerate(total_change_list, start = 3):
        if row == bottom:
            place = row_index
            minimum = bottom

    result = county_enum(place, minimum)
    print("\nThe largest percent decrease:", result[1]*100,"%", "happened in:", result[0])

def county_enum(num, critical):
    csv_file_path = "USCensusData.csv"

    with open(csv_file_path) as csv_files:
        row_list = csv.reader(csv_files)
        for row_index, row in enumerate(row_list):
            if row_index > 2 and row_index == num:
                return row[0], critical

def main():
    csv_file_path = "USCensusData.csv"


    total_change_list = []

    with open(csv_file_path) as csv_files:
        row_list = csv.reader(csv_files)
        for row_index, row in enumerate(row_list):
            if row_index > 2:
                total_change = (float(row[12]) - float(row[3])) / float(row[3])
                total_change_list.append(total_change)
                if total_change == 1.3431066749844043:
                    print(row_index, total_change)

        peak = max(total_change_list)

        bottom = min(total_change_list)

        finding_max(total_change_list, peak)

        finding_min(total_change_list, bottom)

        US_growth_10to19 = total_change_list[0]*100

        print("\nCompare to the US  rate of growth:", US_growth_10to19, "%")

main()