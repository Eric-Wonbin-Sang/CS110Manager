import csv

with open('COVID Airport Traffic.csv') as file:
    reader = csv.reader(file)

    print("The occurence of the COVID-19 pandemic significantly "
          "decreased the amount of vehicle traffic worldwide.\n"
          "This program will present the percent of baseline of the "
          "volume of traffic for various airports on a specified "
          "date during the pandemic.\nThe date range for the data "
          "collected in this is 3/16/2020 - 10/16/2020.")

    month = input("Enter the month you would like to see airport "
                  "traffic data for as an integer (within the "
                  "specified date range): ")

    day = input("Enter the day you would like to see airport traffic "
                "data for as an integer within this month (within the "
                "specified date range): ")

    baseline_list = []

    for row in reader:
        if row[1] != "Date":
            date = row[1].split("/")
            the_month = date[0]
            the_day = date[1]
            if the_month == month:
                if the_day == day:
                    baseline_list.append(row[3])
                    
    sum = 0
    for i in baseline_list:
        sum = sum + int(i)
    average = sum / len(baseline_list)
    
    print("The percent of baseline for " + month +
          "/" + day + "/2020 is " + str(average) + "%.")
    print("This means that " + str(average) + "% of the "
          "number of trips taken on this day of the week "
          "during the baseline period were taken on "
          + month + "/" + day + "/2020.")
