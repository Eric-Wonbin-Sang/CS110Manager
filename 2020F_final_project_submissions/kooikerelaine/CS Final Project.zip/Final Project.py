import csv
import matplotlib.pyplot as plt

#ask user for input of stocks to compare
stocks = (input ("Enter the stock ticker symbols you want to compare. The options are PFE, JNJ, MRNA, NVAX, BNTX, GILD, and INO. " ))


#initialize a path and label list
path_list = []
label_list = []

if ("PFE" in stocks):
    path_list.append('C:/Users/ekkoo/Documents/CS 110 Final Project/PFE (2).csv')
    label_list.append("PFE")
if ("JNJ" in stocks):
    path_list.append('C:/Users/ekkoo/Documents/CS 110 Final Project/JNJ (2).csv')
    label_list.append("JNJ")
if ("MRNA" in stocks):
    path_list.append('C:/Users/ekkoo/Documents/CS 110 Final Project/MRNA (2).csv')
    label_list.append("MRNA")
if ("NVAX" in stocks):
    path_list.append('C:/Users/ekkoo/Documents/CS 110 Final Project/NVAX.csv')
    label_list.append("NVAX")
if ("BNTX" in stocks):
    path_list.append('C:/Users/ekkoo/Documents/CS 110 Final Project/BNTX.csv')
    label_list.append("BNTX")
if ("GILD" in stocks):
    path_list.append('C:/Users/ekkoo/Documents/CS 110 Final Project/GILD.csv')
    label_list.append("GILD")
if ("INO" in stocks):
    path_list.append('C:/Users/ekkoo/Documents/CS 110 Final Project/INO.csv')
    label_list.append("INO")

#path_list =[]
#label_list = ['PFE]
print(path_list, label_list)


count = 0

#Construct graph using data from imported lists
for csv_path in path_list:
    date_list = []
    price_list=[]
    with open (csv_path) as csv_file:
        for row in list(csv.reader(csv_file))[1:]:
            date_list.append(row[0])
            price_list.append(float(row[4]))
    plt.plot(date_list, price_list, label=label_list[count])
    count+=1

#add labels to graph
plt.xlabel('2020')
plt.ylabel('Closing Price')
plt.title('2020 Pharmaceutical Stock Comparison')
plt.legend()
#plt.autoscale()
plt.grid()
plt.show()

