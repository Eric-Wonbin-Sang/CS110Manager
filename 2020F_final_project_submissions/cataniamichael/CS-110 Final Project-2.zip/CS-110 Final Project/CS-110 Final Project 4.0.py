#This program gives information about musical artists and their songs
#It then suggests songs based off of user choices
import lyricsgenius
genius = lyricsgenius.Genius("BAszGOgQASyWG-uVXz6IYbafTy8oGP5JZfTIcnv7eXymXwX3guIdpXhr8QcbmUbR")
def rock():
    print("")
    print("Choose a song to view info, suggestions and lyrics:")
    print("")
    print("Choose 1 for Stairway to Heaven")
    print("Choose 2 for Smells like Teen Spirit")
    print("Choose 3 for Baba O'Riley")
    print("Choose 4 for Sweet Home Alabama")
    print("Choose 5 for Enter Sandman")
    print("")
    rch = int(input("Enter the number that corresponds to your choice:"))
    if rch == 1:
        print("")
        f = open("Rock_Stairway_to_Heaven .txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("Stairway to Heaven", "Led Zeppelin")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif rch == 2:
        print("")
        f = open("Rock_Smells_Like_Teen_Spirit.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("Smells Like Teen Spirit", "Nirvana")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif rch == 3:
        print("")
        f = open("Rock_Baba_O'Riley.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("Baba O'Riley", "The Who")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif rch == 4:
        print("")
        f = open("Rock_Sweet_Home_Alabama.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("Sweet Home Alabama", "Lynryd Skynyrd")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif rch == 5:
        print("")
        f = open("Rock_Enter_Sandman.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("Enter Sandman", "Metallica")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    else:
        print("This entry is invalid")
def pop():
    print("")
    print("Choose a song to view info, suggestions and lyrics:")
    print("")
    print("Choose 1 for Thriller")
    print("Choose 2 for Raspberry Beret")
    print("Choose 3 for Rolling in the Deep")
    print("Choose 4 for I Want it That Way")
    print("Choose 5 for Uptown Funk")
    print("")
    pch = int(input("Enter the number that corresponds to your choice:"))
    if pch == 1:
        print("")
        f = open("Pop_Thriller.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("Thriller", "Michael Jackson")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif pch == 2:
        print("")
        f = open("Pop_Rasberry_Beret.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("Raspberry Beret", "Prince")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif pch == 3:
        print("")
        f = open("Pop_Rolling_In_The_Deep.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("Rolling in the Deep", "Adele")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif pch == 4:
        print("")
        f = open("Pop_I_Want_It_That_Way.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("I Want It That Way", "Backstreet Boys")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif pch == 5:
        print("")
        f = open("Pop_Uptown_Funk.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("Uptown Funk", "Bruno Mars")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    else:
        print("This entry is invalid")
def disco():
    print("")
    print("Choose a song to view info, suggestions and lyrics:")
    print("")
    print("Choose 1 for Y.M.C.A")
    print("Choose 2 for Night Fever")
    print("Choose 3 for I Will Survive")
    print("Choose 4 for Funkytown")
    print("Choose 5 for It's Raining Men")
    print("")
    rach = int(input("Enter the number that corresponds to your choice:"))
    if rach == 1:
        print("")
        f = open("Disco_YMCA.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("Y.M.C.A", "Village People")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif rach == 2:
        print("")
        f = open("Disco_Night_Fever.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("Night Fever", "Bee Gees")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif rach == 3:
        print("")
        f = open("Disco_I_Will_Survive.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("I Will Survive", "Gloria Gaynor")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif rach == 4:
        print("")
        f = open("Disco_Funkytown.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("Funkytown", "Lipps Inc.")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif rach == 5:
        print("")
        f = open("Disco_Its_Raining_Men.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("Its Raining Men", "The Weather Girls")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    else:
        print("This entry is invalid")
def country():
    print("")
    print("Choose a song to view info, suggestions and lyrics:")
    print("")
    print("Choose 1 for The Gambler")
    print("Choose 2 for The Devil Went Down to Georgia")
    print("Choose 3 for Chicken Fried")
    print("Choose 4 for Jolene")
    print("Choose 5 for I Walk the Line")
    print("")
    coch = int(input("Enter the number that corresponds to your choice:"))
    if coch == 1:
        print("")
        f = open("DCounty_The_Gambler.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("The Gambler", "Kenny Rogers")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif coch == 2:
        print("")
        f = open("DCountry_The_Devil_Went_Down_to_Georgia.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("The Devil Went Down to Georgia", "Charlie Daniels Band")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif coch == 3:
        print("")
        f = open("DCountry_Chicken_Fried.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("Chicken Fried", "Zac Brown Band")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif coch == 4:
        print("")
        f = open("DCountry_Jolene.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("Jolene", "Dolly Parton")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    elif coch == 5:
        print("")
        f = open("DCountry_I_Walk_the_Line.txt", "r")
        print(f.read())
        print("Would you like to see the lyrics to this song?")
        lch = int(input("Type 1 for Yes or 2 for No:"))
        if lch == 1:
            song = genius.search_song("I Walk the Line", "Johnny Cash")
            print(song.lyrics)
        elif lch == 2:
            print("Okay.")
        else:
            print("This input is invalid.")
    else:
        print("This entry is invalid")
def artist():
    print("")
    print("Pick a music genre:")
    print("")
    print("Enter 1 for Rock")
    print("Enter 2 for Pop")
    print("Enter 3 for Disco")
    print("Enter 4 for Country")
    gch = int(input("Enter the number that corresponds to your choice:"))
    if gch == 1:
        return rock()
    elif gch == 2:
        return pop()
    elif gch == 3:
        return disco()
    elif gch == 4:
        return country()
    else:
        print("This entry is invalid")
def main():
    print("This program allows you to pick a song from our library")
    print("And see information, lyrics and reccomendations")
    return artist()
main()
