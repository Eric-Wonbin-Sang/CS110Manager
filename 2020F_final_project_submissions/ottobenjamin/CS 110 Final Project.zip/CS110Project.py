import csv
import matplotlib.pyplot as plt

#This program will take the one year history of the TSLA stock and show the 52 week range
#It also shows the percent growth over every month and also over the year
#The code will also graph the stock price of TSLA

def get_ticker_from_file_path(file_path):
    return file_path.split(".")[0]

class Day:
    def growth(self):
        return ((self.close - self.open) / self.open)

    def __init__(self, stock_ticker, csv_file):
        self.stock_ticker=stock_ticker
        self.date=csv_file[0]
        self.open=float(csv_file[1])
        self.high=float(csv_file[2])
        self.low=float(csv_file[3])
        self.close=float(csv_file[4])
        self.month=int(self.date[0])
        self.growth=self.growth()
        if (self.date[1]!='/'):
            self.month=int(self.date[0:2])


    def __str__(self):
        return "Day- Date: {}, Open: {}, High: {}, Low: {}, Close: {}, Growth: {:.2f}%".format(
            self.date,self.open,self.high,self.low,self.close,self.growth
        )

def month_growth(month):
    if (len(month)!=0):
        last=month[len(month)-1]
        first=month[0]
        return ((last.close-first.open)/first.open)
    return 0.00

def update_and_show_graph(ticker):
    plt.xlabel("Date")
    plt.ylabel("Price")
    plt.xticks(rotation=45)
    plt.title(ticker)
    plt.legend(loc="upper left")
    plt.grid()
    plt.show()

def main():
    csv_file_path=input("Put the name of the file here, followed by \".csv\"")
    ticker=get_ticker_from_file_path(csv_file_path)
    day_list=[]
    with open(csv_file_path) as csv_files:
        row_list=csv.reader(csv_files)
        for row_index, row in enumerate(row_list):
            #first iteration row_index=0, row = Date, Open, Close, Adj Close, Volume
            # second iteration row_index=1, row = 2020.07.07,...
            if (row_index!=0):
                day_list.append(Day(ticker,row))
    for day in day_list:
        print(day)
    date_list=[]
    low_list=[]
    high_list=[]
    for day in day_list:
        date_list.append(day.date)
        low_list.append(day.low)
        high_list.append(day.high)
    plt.plot(date_list,low_list,label="Low")
    plt.plot(date_list,high_list,label="High")
    update_and_show_graph(ticker)
    max=0
    max_date=""
    min_date=""
    min=9999999

    for i in range(len(high_list)):
        if (high_list[i]>max):
            max_date=date_list[i]
            max=high_list[i]
    for j in range(len(low_list)):
        if (low_list[j]<min):
            min=low_list[j]
            min_date=date_list[j]
    print ("The max value was {:.2f}, which occured on {}. The min value was {:.2f}, which occured on {}".format(
        max,max_date,min,min_date
    ))
    jan_list=[]
    feb_list=[]
    mar_list=[]
    apr_list=[]
    may_list=[]
    jun_list=[]
    jul_list=[]
    aug_list=[]
    sep_list=[]
    oct_list=[]
    nov_list=[]
    dec_list=[]
    for i in day_list:
        if (i.month==1):
            jan_list.append(i)
        elif (i.month==2):
            feb_list.append(i)
        elif (i.month==3):
            mar_list.append(i)
        elif (i.month==4):
            apr_list.append(i)
        elif (i.month==5):
            may_list.append(i)
        elif (i.month==6):
            jun_list.append(i)
        elif (i.month==7):
            jul_list.append(i)
        elif (i.month==8):
            aug_list.append(i)
        elif (i.month==9):
            sep_list.append(i)
        elif (i.month==10):
            oct_list.append(i)
        elif (i.month==11):
            nov_list.append(i)
        elif (i.month==12):
            dec_list.append(i)
    print ("The total growth is {:.2f}%".format(month_growth(day_list)))
    print("The monthly growth: \nJan: {:.2f}%\nFeb: {:.2f}%\nMar: {:.2f}%\nApr: {:.2f}%\nMay: {:.2f}%\nJun: {:.2f}%\nJul: {:.2f}%\nAug: {:.2f}%\nSep: {:.2f}%\nOct: {:.2f}%\nNov: {:.2f}%\nDec: {:.2f}%".format(
        month_growth(jan_list),
        month_growth(feb_list),
        month_growth(mar_list),
        month_growth(apr_list),
        month_growth(may_list),
        month_growth(jun_list),
        month_growth(jul_list),
        month_growth(aug_list),
        month_growth(sep_list),
        month_growth(oct_list),
        month_growth(nov_list),
        month_growth(dec_list)
    ))
main()