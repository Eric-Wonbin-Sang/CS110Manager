# finalProject.py
# By Rachel Potter

import csv
import matplotlib.pyplot as plt


def graph_csv(files, x_axis_label, timeframe):
    csv_path_list = files
    count = 0  # initialize a variable to 0 for the labels
    # We need two for loops: one to open the files and get the wanted rows, and one to write the lists to the graph
    for csv_path in csv_path_list:
        date_list = []
        price_list = []
        with open(csv_path) as csv_file:
            # For each row in the file (excluding headings), we read it as a list with each row as a line
            for row in list(csv.reader(csv_file))[1:]:
                date_list.append(row[0])  # Add the date (0th element on each line/row) to date_list
                price = row[2].replace(",", "")  # Get rid of commas in the numbers (which are strings)
                price_list.append(float(price) * 0.00092)  # Add the prices to price list, using a conversion factor
            plt.plot(date_list, price_list, label=label_list[count])
            count = count + 1
    # Plot the graph
    plt.xlabel(x_axis_label)  # Name of x label
    plt.ylabel("Price (in USD)")  # Name of y label
    plt.title("Stock Prices of Korean Entertainment Companies:" + " " + timeframe)  # Name of graph
    plt.xticks(rotation=90)  # Rotate the x ticks by 90 degrees for legibility
    plt.legend(loc="upper left")  # Location of the legend for what each line represents
    plt.grid()  # Grid for the graph
    plt.show()  # Show the graph


label_list = [
    "Cube",
    "FNC",
    "JYP",
    "SM",
    "YG",
]


def one():
    file_list = ["Cube - Since 2016.csv",
                 "FNC - Since 2016.csv",
                 "JYP - Since 2016.csv",
                 "SM - Since 2016.csv",
                 "YG - Since 2016.csv"]
    graph_csv(file_list, "Date (year-month)", "2016-2020")


def two():
    file_list = ["Cube - 2020.csv",
                 "FNC - 2020.csv",
                 "JYP - 2020.csv",
                 "SM - 2020.csv",
                 "YG - 2020.csv"]
    graph_csv(file_list, "Date (by week)", "2020")


def three():
    file_list = ["Cube - Month.csv",
                 "FNC - Month.csv",
                 "JYP - Month.csv",
                 "SM - Month.csv",
                 "YG - Month.csv"]
    graph_csv(file_list, "Date (by day)", "1 Month")


def which_graph():
    print("This program compares the stock prices (in USD) for South Korean entertainment companies on a graph.")
    print("Companies involved: Cube, FNC, JYP, SM, YG")
    print("Dates can go up until December 11, 2020.")
    print()
    print("To graph prices since 2016 (by month), please enter the number 1.")
    print("To graph prices in 2020 (by week), please enter the number 2.")
    print("To graph prices up to a month back (by day), please enter the number 3.")
    choice = input("Please enter your number: ")
    while choice != "":
        if choice == "1":
            one()
        elif choice == "2":
            two()
        elif choice == "3":
            three()
        else:
            print("You didn't enter a number 1-3!")
        choice = input("Please enter your number: ")


which_graph()

# I pledge my honor that I have abided by the Stevens Honor System.
# Rachel Potter
