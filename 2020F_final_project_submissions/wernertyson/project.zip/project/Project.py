# CS110 Final project
# This program will allow you to analysis the following equities sector stocks:
# Healthcare, Financials, Industrial, Lodging, and Energy
# In each sector, there are three stocks to analyze individually and gauge the best performers

import csv
import os
from matplotlib.pyplot import ylabel, plot, xticks, show, xlabel


def energy():
    csv_files = "/Users/tyson/PycharmProjects/CS110Project/Energy/"
    csv_file_path_list_energy = []
    for file_path in os.listdir(csv_files):
        csv_file_path_list_energy.append(csv_files + "/" + file_path)

    return csv_file_path_list_energy


def financials():
    csv_files = "/Users/tyson/PycharmProjects/CS110Project/Financials"
    csv_file_path_list_financials = []
    for file_path in os.listdir(csv_files):
        csv_file_path_list_financials.append(csv_files + "/" + file_path)

    return csv_file_path_list_financials


def healthcare():
    csv_files = "/Users/tyson/PycharmProjects/CS110Project/Healthcare"
    csv_file_path_list_healthcare = []
    for file_path in os.listdir(csv_files):
        csv_file_path_list_healthcare.append(csv_files + "/" + file_path)

    return csv_file_path_list_healthcare


def industrial():
    csv_files = "/Users/tyson/PycharmProjects/CS110Project/Industrial"
    csv_file_path_list_industrial = []
    for file_path in os.listdir(csv_files):
        csv_file_path_list_industrial.append(csv_files + "/" + file_path)

    return csv_file_path_list_industrial


def hotels():
    csv_files = "/Users/tyson/PycharmProjects/CS110Project/Hotels"
    csv_file_path_list_hotels = []
    for file_path in os.listdir(csv_files):
        csv_file_path_list_hotels.append(csv_files + "/" + file_path)

    return csv_file_path_list_hotels


def timeseries(csv_file_path):
    date_list, close_list = [], []
    with open(csv_file_path) as csv_file:
        for row in list(csv.reader(csv_file))[1:]:
            date_list.append(row[0])
            close_list.append(float(row[4]))
        return date_list, close_list


def graph(x, y):
    plot(x, y)


def open_graph():
    xlabel("Date")
    ylabel("Closing Price")
    xticks(rotation=90)
    show()


class Day:

    def __init__(self, user_input, stock):

        self.manual_date = user_input

    def compareValues(self,stock):
        date_list = []
        price_list = []
        csv_files = stock
        with open(csv_files) as csv_file:
            for col in list(csv.reader(csv_file))[1:]:
                if str(col[0]) == self.manual_date:
                    date_list.append(col[0])
                    price_list.append(float(col[4]))
                    print(self.manual_date + " " + str(float(col[4])))


def main():

    print("\n\nTHIS TOOK FOREVER TO CODE\n")
    stock = ""
    energyfiles = energy()
    financialfiles = financials()
    healthcarefiles = healthcare()
    industrialfiles = industrial()
    hotelfiles = hotels()


    print(
        "This program will allow you to analyze the following equities sectors based on three stocks in each:\nEnergy, Financial, Healthcare, Industrial, Hotels \n")

    ans = int(input(
        "Please choose a sector: \n 1 for Energy \n 2 for Financial \n 3 for Healthcare \n 4 for Industrial \n 5 for Hotels \n"))

    # energy
    if ans == 1:
        ans2 = int(input(
            "Please choose an energy stock to analyze\n1 for Antero Midstream\n2 for Valero Energy\n3 for EQT Corps\n"))
        if ans2 < 1 or ans2 > 3:
            print("You've enter an invalid command.")
            exit()
        ans3 = int(input(
            "Please choose your method of analysis\n1 for the company stock price chart\n2 for the stock price on a specific day\n"))

        if ans3 == 1:
            date1, close1 = timeseries(energyfiles[ans2 - 1])
            graph(date1, close1)
            open_graph()
            exit()

        elif ans3 == 2:
                stock = energyfiles[ans2 - 1]
                date = str(input("Please enter a date (Ex.2020-11-25) to see the stock price for that day\n"))
                price = Day(date, stock)
                price.compareValues(stock)
                exit()

        elif ans3 != 1 & ans3 != 2:
            print("You've enter an invalid command.")
            exit()

    # financial
    if ans == 2:
        ans4 = int(input(
            "Please choose a financial stock to analyze\n1 for Bank of America\n2 for Goldman Sachs\n3 for JP Morgan\n"))
        if ans4 < 1 or ans4 > 3:
            print("You've enter an invalid command.")
            exit()
        ans5 = int(input(
            "Please choose your method of analysis\n1 for the company stock price chart\n2 for the stock price on a specific day\n"))
        if ans5 == 1:
            date1, close1 = timeseries(financialfiles[ans4 - 1])
            graph(date1, close1)
            open_graph()
            exit()

        elif ans5 == 2:
                stock = financialfiles[ans4 - 1]
                date = str(input("Please enter a date (Ex.2020-11-25) to see the stock price for that day\n"))
                price = Day(date,stock)
                price.compareValues(stock)
                exit()

        elif ans5 != 1 & ans5 != 2:
            print("You've enter an invalid command.")
            exit()

    # healthcare
    if ans == 3:
        ans6 = int(input("Please choose a healthcare stock to analyze\n1 for CVS\n2 for PFE\n3 for JNJ\n"))
        if ans6 < 1 or ans6 > 3:
            print("You've enter an invalid command.")
            exit()

        ans7 = int(input(
            "Please choose your method of analysis\n1 for the company stock price chart\n2 for the stock price on a specific day\n"))
        if ans7 == 1:
            date1, close1 = timeseries(healthcarefiles[ans6 - 1])
            graph(date1, close1)
            open_graph()
            exit()

        elif ans7 == 2:

                stock = healthcarefiles[ans6 - 1]
                date = str(input("Please enter a date (Ex.2020-11-25) to see the stock price for that day\n"))
                price = Day(date,stock)
                price.compareValues(stock)
                exit()

        elif ans7 != 1 & ans7 != 2:
            print("You've enter an invalid command.")
            exit()

    # industrial
    if ans == 4:
        ans8 = int(
            input("Please choose an industrial stock to analyze\n1 for Generac\n2 for Energizer\n3 for IHS Markit\n"))
        if ans8 < 1 or ans8 > 3:
            print("You've enter an invalid command.")
            exit()

        ans9 = int(input(
            "Please choose your method of analysis\n1 for the company stock price chart\n2 for the stock price on a specific day\n"))
        if ans9 == 1:
            date1, close1 = timeseries(industrialfiles[ans8 - 1])
            graph(date1, close1)
            open_graph()
            exit()

        elif ans9 == 2:
                stock = industrialfiles[ans8 - 1]
                date = str(input("Please enter a date (Ex.2020-11-25) to see the stock price for that day\n"))
                price = Day(date,stock)
                price.compareValues(stock)
                exit()

        elif ans9 != 1 & ans9 != 2:
            print("You've enter an invalid command.")
            exit()

    # lodging
    if ans == 5:
        ans10 = int(input("Please choose a hotel stock to analyze\n1 for Marriott\n2 for Wyndham\n3 for Hilton\n"))
        if ans10 < 1 or ans10 > 3:
            print("You've enter an invalid command.")
            exit()

        ans11 = int(input(
            "Please choose your method of analysis\n1 for the company stock price chart\n2 for the stock price on a specific day\n"))
        if ans11 == 1:
            date1, close1 = timeseries(hotelfiles[ans10 - 1])
            graph(date1, close1)
            open_graph()
            exit()

        elif ans11 == 2:

                stock = hotelfiles[ans10 - 1]
                date = str(input("Please enter a date (Ex.2020-11-25) to see the stock price for that day\n"))
                price = Day(date,stock)
                price.compareValues(stock)
                exit()

        elif ans11 != 1 & ans7 != 2:
            print("You've enter an invalid command.")
            exit()


main()
