import pandas as pd
import matplotlib.pyplot as plt

class Stock:

    def __init__(self, ticker, dataset):
        self.ticker = ticker
        self.prices = []
        self.total = 0
        self.month = 0
        self.dataset = dataset

    def calculate_by_month(self):
        close_prices = []
        for i in range(73, 253):
            close = self.dataset.at[i, 'Close']
            close_prices.append(close)
        for i in range(0, 5):
            start = close_prices[i * 30]
            end = close_prices[(i + 1) * 30]
            change = (end / start - 1) * 100
            change = change.round(2)
            self.prices.append(change)
    
    def calculate_total(self):
        total_change = self.dataset.at[252, 'Close'] / self.dataset.at[73, 'Close']
        total_change = (total_change-1) * 100
        total_change = total_change.round(2)
        self.total = total_change
    
    def calculate_best_month(self):
        month = 0
        for i in self.prices:
            if (i > month):
                month = i
        self.month = month
        
    
def compare_stocks(stocks_array):
    best_stock = stocks_array[0]
    best_month = stocks_array[0]
    for stock in stocks_array:
        price = stock.total
        month = stock.month
        
        if (price > best_stock.total):
            best_stock = stock
        if (month > best_month.month):
            best_month = stock

    print('The best performing stock was ' + best_stock.ticker + ' with a ' + str(best_stock.total) + '% increase')
    print('The stock with the best 30 day period was an ' + str(best_month.month) + '% increase by ' + best_month.ticker)

    
# Import the stock market data for the biggest 10 stocks in the healthcare sector
# Taken from https://www.investopedia.com/articles/markets/030916/worlds-top-10-health-care-companies-unh-mdt.asp
abc = Stock('ABC', pd.read_csv("ABC.csv").tail(180))
antm = Stock('ANTM', pd.read_csv("ANTM.csv").tail(180))
cah = Stock('CAH', pd.read_csv("CAH.csv").tail(180))
ci = Stock('CI', pd.read_csv("CI.csv").tail(180))
cnc = Stock('CNC', pd.read_csv("CNC.csv").tail(180))
cvs = Stock('CVS', pd.read_csv("CVS.csv").tail(180))
jnj = Stock('JNJ', pd.read_csv("JNJ.csv").tail(180))
mck = Stock('MCK', pd.read_csv("MCK.csv").tail(180))
unh = Stock('UNH', pd.read_csv("UNH.csv").tail(180))
wba = Stock('WBA', pd.read_csv("WBA.csv").tail(180))
stocks_array = [abc, antm, cah, ci, cnc, cvs, jnj, mck, unh, wba]

# Creating the graphs for the stocks
fig = plt.figure()
ax1 = fig.add_subplot(431)
ax2 = fig.add_subplot(432)
ax3 = fig.add_subplot(433)
ax4 = fig.add_subplot(434)
ax5 = fig.add_subplot(435)
ax6 = fig.add_subplot(436)
ax7 = fig.add_subplot(437)
ax8 = fig.add_subplot(438)
ax9 = fig.add_subplot(439)
ax10 = fig.add_subplot(4, 3, 11)
ax1.set_title('ABC')
ax2.set_title('ANTM')
ax3.set_title('CAH')
ax4.set_title('CI')
ax5.set_title('CNC')
ax6.set_title('CVS')
ax7.set_title('JNJ')
ax8.set_title('MCK')
ax9.set_title('UNH')
ax10.set_title('WBA')

plots = [ax1, ax2, ax3, ax4, ax5, ax6, ax7, ax8, ax9, ax10]
plot_counter = 0

# Plot the closing price of the 10 stocks over the last 180 days
# Perform calculations for the 10 stocks to produce their total change and 30 day period change
for stock in stocks_array:
    stock.calculate_total()
    stock.calculate_by_month()
    stock.calculate_best_month()
    
    plots[plot_counter].plot(stock.dataset['Close'])
    plot_counter += 1
    
# Determines the stock with the best total change and best 30 day period
compare_stocks(stocks_array)

# Shows the plotted stocks
plt.tight_layout()
plt.show()