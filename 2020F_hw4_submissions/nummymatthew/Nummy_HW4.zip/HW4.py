##################################################################################################################################
# Name        : Matthew Nummy
# Date        : 10/30/2020
# Assignment  : Homework 4
# Description : This program reads a text file of lowercase names and creates a second text file with the same names capitalized.
# Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
##################################################################################################################################

def main():
    infile = open("Before.txt", "r")
    outfile = open("After.txt", "w")

    for i in infile:
        name = i.upper()
        print(name, file=outfile)

    infile.close()
    outfile.close()
main()
