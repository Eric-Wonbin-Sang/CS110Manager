# Stephanie Gillow
# CS 110
# 10/29/20
# I pledge my honor I have abided by the Stevens honor system.

import os


def uppercase(infileName, outfileName):
    replaceDict = {'a': 'A', 'b': 'B', 'c': 'C', 'd': 'D', 'e': 'E', 'f': 'F', 'g': 'G', 'h': 'H', 'i': 'I',
                   'j': 'J', 'k': 'K', 'l': 'L', 'm': 'M', 'n': 'N', 'o': 'O', 'p': 'P', 'q': 'Q', 'r': 'R',
                   's': 'S', 't': 'T', 'u': 'U', 'v': 'V', 'w': 'W', 'x': 'X', 'y': 'Y', 'z': 'Z'}
    with open(infileName) as infile, open(outfileName, 'w') as outfile:
        for line in infile:
            for src, target in replaceDict.items():
                line = line.replace(src, target)
            outfile.write(line)


uppercase(os.path.join('Before.txt'), os.path.join('After.txt'))
