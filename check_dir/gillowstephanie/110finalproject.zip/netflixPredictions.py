# Stephanie Gillow
# 12/13/2020
# CS 110 final project
# linear regression prediction model, tailored to Netflix subscriber counts
# I pledge my honor I have abided by the Stevens honor system.

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

# reading in the CSV we're basing the regression model on - this is formatted without quarterly labels so it
# can be parsed correctly.
# data from statista -
# https://www.statista.com/statistics/250937/quarterly-number-of-netflix-streaming-subscribers-in-the-us/
df = pd.read_csv("netflix.csv")

# sets x-axis to the 1st column of the imported CSV, y-axis to the 2nd
x = df.iloc[:, :-1]
y = df.iloc[:, 1]
# training and testing the model using the imported data
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=0)
simplelinearRegression = LinearRegression()
simplelinearRegression.fit(x_train, y_train)
LinearRegression(copy_X=True, fit_intercept=True, n_jobs=None, normalize=False)
# the y-axis is our dependent variable, so that's what we're predicting
y_predict = simplelinearRegression.predict(x_test)
predict = pd.DataFrame(y_predict)
predict.apply(np.round)


# these have barely anything to do with what I did, literally just here to fix a labeling issue
def swapto4(number):
    # swaps 0 to 4 so my quarter labels aren't whack
    number += identify0(number)
    return number


def identify0(number):
    # helper function for swapto4(), figures out whether something is a 0 and does the swapping work
    result = 0
    dec = 1
    if (number == 0):
        result += (4 * dec)
    while (number > 0):
        if (number % 10 == 0):
            result += (4 * dec)
        number //= 10
        dec *= 10

    return result


# counter
i = 1
# the ending digits of the years for the quarter labels
yearEnd = 12

# opening our prediction CSV file to write the predictions to it
filePredictions = open('netflixP.csv', 'w')
# putting the header in
filePredictions.write("Quarter,Subscribers\n")
# modeling the data we already have, so the entire graph is purely machine learning-based
while i <= 35:
    # printed representation
    print("Modeled number of subscribers in 20" + str(int(yearEnd)) + " Q%d, based on linear regression model, is" % (
        swapto4(i % 4)), int(simplelinearRegression.predict([[i]])), "million")
    filePredictions.write("Q" + str((swapto4(i % 4))) + " 20" + str(int(yearEnd)) + "," + str(
        int(simplelinearRegression.predict([[i]]))) + "\n")
    i = i + 1
    # adds .25 to yearEnd, doing this and then casting it to an int means it'll change to the next year
    # after 4 quarters appropriately. it's also cast to a string because otherwise there's an ugly space in between
    yearEnd = yearEnd + .25
# same exact algorithm - just for data we don't have yet, so changing the message to "predicted"
while i <= 40:
    print("Predicted number of subscribers in 20" + str(int(yearEnd)) + " Q%d is" % (swapto4(i % 4)),
          int(simplelinearRegression.predict([[i]])), "million")
    filePredictions.write("Q" + str((swapto4(i % 4))) + " 20" + str(int(yearEnd)) + "," + str(
        int(simplelinearRegression.predict([[i]]))) + "\n")
    i = i + 1
    yearEnd = yearEnd + .25
# all done with our predictions CSV - time to graph!
filePredictions.close()

# using pandas to read in our CSVs and store them as dataframes for our graphs
dataframeActual = pd.read_csv('netflixQ.csv')
dataframePredicted = pd.read_csv('netflixP.csv')

# now using matplotlib - setting up the canvas for our subplots so they can be side-by-side
fig = plt.figure(figsize=(20, 5))
# adding said subplots - (nrows, ncols, index)
act = fig.add_subplot(1, 2, 1)
pred = fig.add_subplot(1, 2, 2)
# populating the bar graph for the real-world data
# our x- and y-axes based on the CSV headers
act.bar(dataframeActual['Quarter'], dataframeActual['Subscribers'])
# the x-axis labels, based on the quarterly labels, rotated so they're readable
act.set_xticklabels(dataframeActual['Quarter'], rotation=45)
# top title
act.set_title('Actual Netflix Subscribers Over Time', fontsize=22)
# y-axis labels
act.set_ylabel('Subscribers in Millions')

pred.bar(dataframePredicted['Quarter'], dataframePredicted['Subscribers'])
pred.set_xticklabels(dataframePredicted['Quarter'], rotation=45)
pred.set_title('Predicted Netflix Subscribers Over Time', fontsize=22)
pred.set_ylabel('Subscribers in Millions')

# print the plots
plt.show()

# great success!!
