import pandas as pd
import csv
import datetime
import wbdata
import matplotlib.pyplot as plt

indicator1 = {'SP.POP.TOTL':'Percent Change in TP', "NY.GDP.MKTP.CD":"Percent Change in GDP"}
indicator2 = {'SP.POP.TOTL':'Percent Change in TP', "NY.GNP.ATLS.CD":"Percent Change in GNI"}


country_code_file = "/Users/melissaatmaca/Desktop/Country_Codes.csv"


print("This program is aimed to find the correlation within the human factor and consumption and production economies as a whole.")
print("Thereby, it strives to allow users to compare two or more countries on graphs that combine total population factor",
       "with and utilize two most important indicators: total GDP and total GNI")

x = input("Please input the first country code that you'd like to analyze:")
x = x.upper()

y = input("Please input the second country code that you'd like to analyze:")
y = y.upper()

z = [x, y]

is_infile = False
with open(country_code_file) as csvfile:
    countcode = csv.reader(csvfile)
    for cc in countcode:
        if x in cc:
            is_infile = True
            if y in cc:
                is_infile = True
            i1 = input("If you'd like to see the graph displaying the percent changes in total population and GDP, enter GDP, if not, enter GNI: ")
            i1 = i1.upper()




data_time = datetime.datetime(2000, 1, 1), datetime.datetime(2019, 1, 1)
if i1 == "GDP":
    data = wbdata.get_dataframe(indicator1, country=z, data_date=data_time)
    data = data.iloc[::-1]
    data = data.pct_change()

    dfu = data.unstack(level=0)
    dfu.plot();
    plt.legend(loc='best');
    plt.title("Percent Change in GDP and Population");
    plt.ylim([-.3, .3])
    plt.xlabel('Date');
    plt.ylabel("Percent Change");
    plt.show()
elif i1 == "GNI":
    data = wbdata.get_dataframe(indicator2, country=z, data_date=data_time)
    data = data.iloc[::-1]
    data = data.pct_change()

    dfu = data.unstack(level=0)
    dfu.plot();
    plt.legend(loc='best');
    plt.title("Percent Change in GNI and Population");
    plt.ylim([-.3, .3])
    plt.xlabel('Date');
    plt.ylabel("Percent Change");
    plt.show()
else:
    print("You did not input a valid entry.")

